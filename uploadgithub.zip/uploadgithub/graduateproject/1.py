import numpy as np
import cv2
import matplotlib.pyplot as plt
import time

def calculate_local_std(image, win_size):
    """
    计算图像的局部标准差
    :param image: 输入图像
    :param win_size: 窗口大小
    :return: 局部标准差图
    """
    pad = win_size // 2
    padded_image = cv2.copyMakeBorder(image, pad, pad, pad, pad, cv2.BORDER_REFLECT)
    local_mean = cv2.blur(padded_image, (win_size, win_size))
    local_mean_sq = cv2.blur(padded_image ** 2, (win_size, win_size))
    local_std = np.sqrt(local_mean_sq - local_mean ** 2)
    return local_std[pad:-pad, pad:-pad]

def adaptive_lig_detection(image_path):
    """
    自适应窗口大小的局部强度和梯度特征检测（优化版）
    """
    start_time = time.time()

    # 读取图像并进行预处理
    src = cv2.imread(image_path)
    if src is None:
        raise FileNotFoundError(f"Image not found: {image_path}")

    # 转换为灰度图并去噪
    src_gray = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY)
    src_gray = cv2.medianBlur(src_gray, 3)  # 中值滤波去噪
    image = src_gray.astype(np.float32)

    # 图像尺寸
    Xsize, Ysize = src_gray.shape

    # 计算局部标准差（改进版）
    local_std = calculate_local_std(image, win_size=3)

    # 初始化特征图
    gmap = np.zeros_like(image)
    imap = np.zeros_like(image)

    # 动态窗口大小选择
    win_sizes = np.zeros_like(image, dtype=np.int32)
    for i in range(Xsize):
        for j in range(Ysize):
            # 使用更精细的窗口大小选择策略
            if local_std[i, j] > 25:  # 较高对比度区域，使用较小窗口
                win_sizes[i, j] = 3
            elif local_std[i, j] > 10:  # 中等对比度区域，使用中等窗口
                win_sizes[i, j] = 5
            else:  # 低对比度区域，使用较大窗口
                win_sizes[i, j] = 7

    # 改进的局部强度计算
    local_mean = np.zeros_like(image)
    for i in range(Xsize):
        for j in range(Ysize):
            win_size = win_sizes[i, j]
            pad = win_size // 2
            x_start = max(i - pad, 0)
            x_end = min(i + pad + 1, Xsize)
            y_start = max(j - pad, 0)
            y_end = min(j + pad + 1, Ysize)
            region = image[x_start:x_end, y_start:y_end]
            local_mean[i, j] = np.mean(region)
    imap = image - local_mean

    # 改进梯度特征计算（使用 Canny 边缘检测）
    gmap = cv2.Canny(src_gray, 50, 150)  # 自动阈值的 Canny 边缘检测
    gmap = gmap.astype(np.float32) / 255.0  # 归一化到 [0, 1]

    # 归一化处理
    imap = (imap - np.min(imap)) / (np.max(imap) - np.min(imap) + 1e-6)
    gmap = (gmap - np.min(gmap)) / (np.max(gmap) - np.min(gmap) + 1e-6)

    # 自适应特征融合
    imap_var = np.var(imap)
    gmap_var = np.var(gmap)
    total_var = imap_var + gmap_var
    if total_var != 0:
        imap_weight = imap_var / total_var
        gmap_weight = gmap_var / total_var
    else:
        imap_weight = 0.5
        gmap_weight = 0.5

    combined_map = imap_weight * imap + gmap_weight * gmap

    # 归一化 combined_map 到 [0, 255] 范围，并转换为 uint8 类型
    combined_map_scaled = (combined_map * 255).astype(np.uint8)

    # 自适应阈值处理
    _, binary_map = cv2.threshold(combined_map_scaled, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    binary_map = binary_map.astype(np.float32) / 255.0  # 转换回 float32 类型

    # 后处理（形态学操作）
    kernel = np.ones((3, 3), np.uint8)
    binary_map = cv2.morphologyEx(binary_map.astype(np.uint8), cv2.MORPH_OPEN, kernel)
    binary_map = cv2.morphologyEx(binary_map, cv2.MORPH_CLOSE, kernel)

    end_time = time.time()
    run_time = end_time - start_time
    print(f"目标检测运行时间: {run_time:.4f} 秒")

    # 可视化结果
    plt.figure(figsize=(15, 10))
    plt.subplot(2, 3, 1), plt.imshow(cv2.cvtColor(src, cv2.COLOR_BGR2RGB)), plt.title('Original Image')
    plt.subplot(2, 3, 2), plt.imshow(local_std, cmap='gray'), plt.title('Local Std Dev Map')
    plt.subplot(2, 3, 3), plt.imshow(win_sizes, cmap='jet'), plt.title('Adaptive Window Sizes')
    plt.subplot(2, 3, 4), plt.imshow(imap, cmap='gray'), plt.title('Improved Local Intensity Map')
    plt.subplot(2, 3, 5), plt.imshow(gmap, cmap='gray'), plt.title('Gradient Feature Map (Canny)')
    plt.subplot(2, 3, 6), plt.imshow(binary_map, cmap='gray'), plt.title('Binary Result (Post-Processed)')
    plt.tight_layout()
    plt.show()

    return binary_map

# 使用示例
image_path = 'D://graduateproject//picture//10.png'
binary_map = adaptive_lig_detection(image_path)