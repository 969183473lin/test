import numpy as np
import cv2
import matplotlib.pyplot as plt
import time
from sklearn.mixture import GaussianMixture
from sklearn.neighbors import LocalOutlierFactor

def calculate_local_std(image, win_size):
    pad = win_size // 2
    padded_image = cv2.copyMakeBorder(image, pad, pad, pad, pad, cv2.BORDER_REFLECT)
    local_mean = cv2.blur(padded_image, (win_size, win_size))
    local_mean_sq = cv2.blur(padded_image ** 2, (win_size, win_size))
    local_std = np.sqrt(local_mean_sq - local_mean ** 2)
    return local_std[pad:-pad, pad:-pad]

def adaptive_lig_detection(image_path, min_win_size=3, max_win_size=7, imap_weight=0.28, gmap_weight=0.2):
    start_time = time.time()
    src = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if src is None:
        raise FileNotFoundError(f"Image file not found: {image_path}")
    Xsize, Ysize = src.shape
    image = src.astype(np.float32)

    # 自适应窗口大小选择
    local_std = calculate_local_std(image, win_size=3)
    win_sizes = np.zeros_like(local_std, dtype=np.int32)
    for i in range(Xsize):
        for j in range(Ysize):
            if local_std[i, j] > 20:
                win_sizes[i, j] = min_win_size
            elif local_std[i, j] > 10:
                win_sizes[i, j] = 5
            else:
                win_sizes[i, j] = max_win_size

    # 计算局部均值
    local_mean = np.zeros_like(image)
    for i in range(Xsize):
        for j in range(Ysize):
            win_size = win_sizes[i, j]
            pad = win_size // 2
            region = image[max(i - pad, 0):min(i + pad + 1, Xsize), max(j - pad, 0):min(j + pad + 1, Ysize)]
            local_mean[i, j] = np.mean(region)
    imap = image - local_mean

    # 计算梯度（使用Canny边缘检测减少噪声）
    edges = cv2.Canny(image.astype(np.uint8), 50, 150)
    grad_x = cv2.Sobel(image, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(image, cv2.CV_32F, 0, 1, ksize=3)
    gmap = np.maximum(np.abs(grad_x), np.abs(grad_y))
    gmap[edges == 0] = 0  # 抑制非边缘区域的梯度

    # 归一化
    imap = (imap - imap.min()) / (imap.max() - imap.min() + 1e-6)
    gmap = (gmap - gmap.min()) / (gmap.max() - gmap.min() + 1e-6)

    # 结合特征
    combined_map = imap_weight * imap + gmap_weight * gmap
    # 去噪处理
    combined_map = cv2.GaussianBlur(combined_map, (3, 3), 0)  # 高斯滤波

    end_time = time.time()
    run_time = end_time - start_time
    print(f"局部特征检测运行时间: {run_time:.4f} 秒")

    return combined_map

def enhance_local_combined_map(combined_map, background_window_size=15):
    start_time = time.time()
    # 计算背景平均值
    background_mean = cv2.blur(combined_map, (background_window_size, background_window_size))

    # 从原始图中减去背景平均值
    enhanced_map = combined_map - background_mean

    # 确保结果在合理范围内
    enhanced_map = np.clip(enhanced_map, 0, 1)

    end_time = time.time()
    run_time = end_time - start_time
    print(f"增强运行时间: {run_time:.4f} 秒")

    return enhanced_map

def calculate_global_rarity_density(enhanced_map, n_components=3):
    start_time = time.time()
    Xsize, Ysize = enhanced_map.shape
    Z = enhanced_map.reshape((-1, 1))

    # 使用高斯混合模型进行密度估计
    gmm = GaussianMixture(n_components=n_components, random_state=42)
    gmm.fit(Z)

    # 计算每个像素的概率密度
    probabilities = np.exp(gmm.score_samples(Z))

    # 将概率密度归一化到[0, 1]
    probabilities = probabilities / probabilities.max()

    # 计算稀有度得分（低概率区域得分高）
    rarity_scores = 1 - probabilities

    # 结合稀有度得分和像素值
    combined_scores = rarity_scores * Z.flatten()

    # 生成稀有度图
    rarity_map = combined_scores.reshape((Xsize, Ysize))

    end_time = time.time()
    run_time = end_time - start_time
    print(f"基于密度估计的全局稀有度计算运行时间: {run_time:.4f} 秒")

    return rarity_map

def extract_rarest_brightest_points_density(enhanced_map, n_points=100, n_components=3):
    start_time = time.time()
    Xsize, Ysize = enhanced_map.shape
    Z = enhanced_map.reshape((-1, 1))

    # 计算稀有度得分
    rarity_map = calculate_global_rarity_density(enhanced_map, n_components)

    # 选择最稀有且最亮的点
    top_indices = np.argsort(rarity_map.flatten())[-n_points:]

    # 生成最终结果图
    final_result = np.zeros((Xsize, Ysize), dtype=np.uint8)
    final_result.flat[top_indices] = 255

    # 形态学操作：腐蚀和膨胀
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    final_result = cv2.erode(final_result, kernel, iterations=1)  # 腐蚀操作
    final_result = cv2.dilate(final_result, kernel, iterations=1)  # 膨胀操作

    # 形态学开运算去除小的非目标区域
    final_result = cv2.morphologyEx(final_result, cv2.MORPH_OPEN, kernel, iterations=1)

    end_time = time.time()
    run_time = end_time - start_time
    print(f"基于密度估计的提取最稀有且最亮的点运行时间: {run_time:.4f} 秒")

    return final_result

def combined_detection_density(image_path, min_win_size=3, max_win_size=7, imap_weight=0.28, gmap_weight=0.2, n_points=100):
    start_time = time.time()

    # 局部特征检测
    local_combined = adaptive_lig_detection(image_path, min_win_size, max_win_size, imap_weight, gmap_weight)

    # 增强处理
    enhanced_map = enhance_local_combined_map(local_combined)

    # 基于密度估计的全局稀有度检测
    rarity_map = calculate_global_rarity_density(enhanced_map, n_components=3)

    # 提取最稀有且最亮的点
    final_result = extract_rarest_brightest_points_density(enhanced_map, n_points, n_components=3)

    # 可视化
    src = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    plt.figure(figsize=(18, 10))
    plt.subplot(1, 5, 1), plt.imshow(src, cmap='gray'), plt.title('Original Image')
    plt.subplot(1, 5, 2), plt.imshow(local_combined, cmap='gray'), plt.title('Local Combined Map')
    plt.subplot(1, 5, 3), plt.imshow(enhanced_map, cmap='gray'), plt.title('Enhanced Map')
    plt.subplot(1, 5, 4), plt.imshow(rarity_map, cmap='gray'), plt.title('Global Rarity Map (Density)')
    plt.subplot(1, 5, 5), plt.imshow(final_result, cmap='gray'), plt.title('Final Result (Density)')
    plt.tight_layout()
    plt.show()

    end_time = time.time()
    total_run_time = end_time - start_time
    print(f"基于密度估计的总运行时间: {total_run_time:.4f} 秒")

    return final_result

def calculate_false_alarm_rate(detection_result, ground_truth):
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    false_alarms = np.sum(detection_result & np.logical_not(ground_truth))
    non_target_areas = np.sum(np.logical_not(ground_truth))

    if non_target_areas == 0:
        return float('inf')  # 避免除以零的情况

    false_alarm_rate = false_alarms / non_target_areas
    return false_alarm_rate

def calculate_recall(detection_result, ground_truth):
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    true_positives = np.sum(detection_result & ground_truth)
    actual_targets = np.sum(ground_truth)

    if actual_targets == 0:
        return float('inf')  # 避免除以零的情况

    recall = true_positives / actual_targets
    return recall

# 使用示例
if __name__ == "__main__":
    image_path = 'D://graduateproject//picture//000094.png'  # 替换为实际图片路径
    ground_truth_path = 'D://graduateproject//masks//000094.png'  # 替换为实际标注路径

    # 检测结果
    final_result = combined_detection_density(image_path)

    # 标注数据
    ground_truth = cv2.imread(ground_truth_path, cv2.IMREAD_GRAYSCALE)
    if ground_truth is None:
        raise FileNotFoundError(f"标注数据文件未找到: {ground_truth_path}")
    ground_truth = ground_truth > 0  # 转换为二值图

    # 计算虚警率
    false_alarm_rate = calculate_false_alarm_rate(final_result, ground_truth)
    print(f"虚警率: {false_alarm_rate:.4f}")

    # 计算召回率
    recall = calculate_recall(final_result, ground_truth)
    print(f"召回率: {recall:.4f}")