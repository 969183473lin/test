from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash
import os
import cv2
import numpy as np
from werkzeug.utils import secure_filename
import time
from sklearn.mixture import GaussianMixture
# 导入各个算法模块
from lcm1 import process_single_image as lcm_metrics
from top_hat1 import process_single_image as top_hat_metrics
from max_median1 import process_single_image as max_median_metrics
from my1 import process_image as my1_metrics

from newtest1 import process_single_image as newtest1_metrics

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['RESULTS_FOLDER'] = 'results'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}
app.secret_key = 'your_secret_key'  # 用于 flash 消息

# 确保上传和结果文件夹存在
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['RESULTS_FOLDER'], exist_ok=True)


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


def calculate_local_std(image, win_size):
    pad = win_size // 2
    padded_image = cv2.copyMakeBorder(image, pad, pad, pad, pad, cv2.BORDER_REFLECT)
    local_mean = cv2.blur(padded_image, (win_size, win_size))
    local_mean_sq = cv2.blur(padded_image ** 2, (win_size, win_size))
    local_std = np.sqrt(local_mean_sq - local_mean ** 2)
    return local_std[pad:-pad, pad:-pad]


def adaptive_lig_detection(image, min_win_size=3, max_win_size=7, imap_weight=0.28, gmap_weight=0.2):
    start_time = time.time()
    image = image.astype(np.float32)
    Xsize, Ysize = image.shape

    local_std = calculate_local_std(image, win_size=3)
    win_sizes = np.zeros_like(image, dtype=np.int32)
    for i in range(Xsize):
        for j in range(Ysize):
            if local_std[i, j] > 20:
                win_sizes[i, j] = min_win_size
            elif local_std[i, j] > 10:
                win_sizes[i, j] = 5
            else:
                win_sizes[i, j] = max_win_size

    local_mean = np.zeros_like(image)
    for i in range(Xsize):
        for j in range(Ysize):
            win_size = win_sizes[i, j]
            pad = win_size // 2
            region = image[max(i - pad, 0):min(i + pad + 1, Xsize),
                     max(j - pad, 0):min(j + pad + 1, Ysize)]
            local_mean[i, j] = np.mean(region)
    imap = image - local_mean

    grad_x = cv2.Sobel(image, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(image, cv2.CV_32F, 0, 1, ksize=3)
    gmap = np.maximum(np.abs(grad_x), np.abs(grad_y))

    imap = (imap - imap.min()) / (imap.max() - imap.min() + 1e-6)
    gmap = (gmap - gmap.min()) / (gmap.max() - gmap.min() + 1e-6)

    combined_map = imap_weight * imap + gmap_weight * gmap
    combined_map = cv2.GaussianBlur(combined_map, (3, 3), 0)

    end_time = time.time()
    run_time = end_time - start_time
    print(f"局部特征检测运行时间: {run_time:.4f} 秒")

    return combined_map


def enhance_local_combined_map(combined_map, background_window_size=15):
    start_time = time.time()
    background_mean = cv2.blur(combined_map, (background_window_size, background_window_size))
    enhanced_map = combined_map - background_mean
    enhanced_map = np.clip(enhanced_map, 0, 1)

    end_time = time.time()
    run_time = end_time - start_time
    print(f"增强运行时间: {run_time:.4f} 秒")

    return enhanced_map


def calculate_global_rarity_multiscale(enhanced_map, scales=[3, 5, 7]):
    start_time = time.time()
    multiscale_features = []

    for scale in scales:
        blurred = cv2.GaussianBlur(enhanced_map, (scale, scale), 0)
        multiscale_features.append(blurred)

    multiscale_features = np.array(multiscale_features)
    feature_variances = np.var(multiscale_features, axis=0)

    Z = feature_variances.reshape((-1, 1))
    gmm = GaussianMixture(n_components=3, random_state=42)
    gmm.fit(Z)
    probabilities = np.exp(gmm.score_samples(Z))
    probabilities = probabilities / probabilities.max()
    rarity_scores = 1 - probabilities
    rarity_map = rarity_scores.reshape(feature_variances.shape)

    end_time = time.time()
    run_time = end_time - start_time
    print(f"基于多尺度特征的全局稀有度计算运行时间: {run_time:.4f} 秒")

    return rarity_map


def fuse_and_normalize(local_map, global_map, alpha=0.1):
    fused_map = alpha * local_map + (1 - alpha) * global_map
    fused_map = (fused_map - fused_map.min()) / (fused_map.max() - fused_map.min() + 1e-6)
    return fused_map


def combined_detection_multiscale(image):
    start_time = time.time()

    local_combined = adaptive_lig_detection(image)
    enhanced_map = enhance_local_combined_map(local_combined)
    global_rarity_map = calculate_global_rarity_multiscale(enhanced_map)
    fused_map = fuse_and_normalize(enhanced_map, global_rarity_map)

    end_time = time.time()
    total_run_time = end_time - start_time
    print(f"基于多尺度特征的总运行时间: {total_run_time:.4f} 秒")

    return fused_map


def calculate_false_alarm_rate(detection_result, ground_truth):
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    false_alarms = np.sum(detection_result & np.logical_not(ground_truth))
    non_target_areas = np.sum(np.logical_not(ground_truth))

    if non_target_areas == 0:
        return float('inf')

    false_alarm_rate = false_alarms / non_target_areas
    return false_alarm_rate


def calculate_recall(detection_result, ground_truth):
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    true_positives = np.sum(detection_result & ground_truth)
    actual_targets = np.sum(ground_truth)

    if actual_targets == 0:
        return float('inf')

    recall = true_positives / actual_targets
    return recall
def get_ground_truth_path(image_path):
    """生成标注文件路径"""
    base_name = os.path.basename(image_path)
    return os.path.join('D:/graduateproject/masks', base_name)

@app.route('/')
def index():
    return render_template('index.html')


from flask import session

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return redirect(request.url)

    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        upload_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(upload_path)

        # 读取图像
        image = cv2.imread(upload_path, cv2.IMREAD_GRAYSCALE)

        # 运行四种算法
        # 1. Combined Detection
        combined_result = combined_detection_multiscale(image)
        combined_result_path = os.path.join(app.config['RESULTS_FOLDER'], f"combined_{filename}")
        cv2.imwrite(combined_result_path, (combined_result * 255).astype(np.uint8))

        # 2. Top-Hat Detection
        from top_hat import top_hat_detection
        top_hat_result = top_hat_detection(image)
        top_hat_result_path = os.path.join(app.config['RESULTS_FOLDER'], f"top_hat_{filename}")
        cv2.imwrite(top_hat_result_path, top_hat_result)

        # 3. LCM Detection
        #from lcm import lcm_detection
        from newtest import lcm_detection
        #lcm_result, _ = lcm_detection(image)
        lcm_result, _ = lcm_detection(image)
        lcm_result_path = os.path.join(app.config['RESULTS_FOLDER'], f"lcm_{filename}")
        cv2.imwrite(lcm_result_path, lcm_result)

        # 4. Max-Median Detection
        from max_median import max_median_detection
        max_median_result = max_median_detection(image)
        max_median_result_path = os.path.join(app.config['RESULTS_FOLDER'], f"max_median_{filename}")
        cv2.imwrite(max_median_result_path, max_median_result)

        # 获取标注文件路径
        ground_truth_path = get_ground_truth_path(upload_path)
        ground_truth = cv2.imread(ground_truth_path, cv2.IMREAD_GRAYSCALE)


        # 计算 Top-Hat Detection 的统计指标
        # 确保传递给 top_hat_metrics 的是文件路径而不是图像数组
        tophat_far, tophat_recall, tophat_precision = top_hat_metrics(upload_path, ground_truth_path)
        lcm_far, lcm_recall, lcm_precision = newtest1_metrics(upload_path, ground_truth_path)
        maxmedian_far, maxmedian_recall, maxmedian_precision = max_median_metrics(upload_path, ground_truth_path)
        combined_far,combined_recall,combined_precision=my1_metrics(upload_path, ground_truth_path)
         # 计算 Combined Detection 的统计指标

        # 将统计指标存储到 session 中
        session['statistics_data'] = {
            "combined": {
                "precision": combined_precision,
                "recall": combined_recall,
                "far": combined_far
            },
            "top_hat": {
                "precision": tophat_precision,
                "recall": tophat_recall,
                "far": tophat_far
            },
            "lcm": {
                "precision": lcm_precision,
                "recall": lcm_recall,
                "far": lcm_far
            },
            "max_median": {
                "precision": maxmedian_precision,
                "recall": maxmedian_recall,
                "far": maxmedian_far
            }
        }

        # 将最新的文件名存储到 session 中
        session['last_filename'] = filename

        return redirect(url_for('result', filename=filename))

    return redirect(request.url)

@app.route('/result')
def result():
    filename = request.args.get('filename')
    if not filename:
        # 从 session 中获取最新的文件名
        filename = session.get('last_filename')
        if not filename:
            # 如果 session 中也没有文件名，检查是否有上次上传的文件
            uploads = os.listdir(app.config['UPLOAD_FOLDER'])
            if uploads:
                filename = uploads[0]
            else:
                flash('请先上传文件', 'warning')
                return redirect(url_for('index'))
    return render_template('result.html', filename=filename)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


@app.route('/results/<filename>')
def results_file(filename):
    return send_from_directory(app.config['RESULTS_FOLDER'], filename)


@app.route('/home')
def home():
    return redirect(url_for('index'))


@app.route('/result-contrast')
def result_contrast():
    # 从 session 中获取最新的文件名
    filename = session.get('last_filename')
    if not filename:
        # 如果 session 中也没有文件名，检查是否有上次上传的文件
        uploads = os.listdir(app.config['UPLOAD_FOLDER'])
        if uploads:
            filename = uploads[0]
        else:
            flash('请先上传文件', 'warning')
            return redirect(url_for('index'))
    return redirect(url_for('result', filename=filename))


@app.route('/statistics')
def statistics():
    # 从 session 中获取统计指标
    statistics_data = session.get('statistics_data', {})

    # 将统计指标传递给模板
    return render_template(
        'statistics.html',
        combined_precision=statistics_data.get('combined', {}).get('precision', 0),
        combined_recall=statistics_data.get('combined', {}).get('recall', 0),
        combined_far=statistics_data.get('combined', {}).get('far', 0),
        tophat_precision=statistics_data.get('top_hat', {}).get('precision', 0),
        tophat_recall=statistics_data.get('top_hat', {}).get('recall', 0),
        tophat_far=statistics_data.get('top_hat', {}).get('far', 0),
        lcm_precision=statistics_data.get('lcm', {}).get('precision', 0),
        lcm_recall=statistics_data.get('lcm', {}).get('recall', 0),
        lcm_far=statistics_data.get('lcm', {}).get('far', 0),
        maxmedian_precision=statistics_data.get('max_median', {}).get('precision', 0),
        maxmedian_recall=statistics_data.get('max_median', {}).get('recall', 0),
        maxmedian_far=statistics_data.get('max_median', {}).get('far', 0)
    )

if __name__ == '__main__':
    app.run(debug=True)