import numpy as np
import cv2
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

def preprocess_image(image_path):
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    image = image.astype(np.float32)
    # 获取图像尺寸
    Xsize, Ysize = image.shape
    # 将图像展平为一维数组
    Z = image.reshape((-1, 1))
    Z = np.float32(Z)
    return Z, Xsize, Ysize

def compute_wcss(Z, max_k=10):
    wcss = []
    K = range(1, max_k + 1)
    for k in K:
        kmeans = KMeans(n_clusters=k, init='k-means++', max_iter=300, n_init=10, random_state=0)
        kmeans.fit(Z)
        wcss.append(kmeans.inertia_)  # inertia_ 获取聚类准则的总和
    return K, wcss

def plot_wcss(K, wcss):
    plt.plot(K, wcss, marker='o', linestyle='-', color='b')
    plt.title('Elbow Method')
    plt.xlabel('Number of clusters (k)')
    plt.ylabel('WCSS')
    plt.grid(True)
    plt.show()

def find_optimal_k(image_path, max_k=10):
    Z, Xsize, Ysize = preprocess_image(image_path)
    K, wcss = compute_wcss(Z, max_k)
    plot_wcss(K, wcss)
    # 从图中观察肘部点，选择最佳的 k 值
    optimal_k = int(input("Enter the optimal k value based on the elbow method: "))
    return optimal_k

# 调用函数
image_path = 'D://graduateproject//picture//15.png'
optimal_k = find_optimal_k(image_path, max_k=10)
print(f"Optimal k value: {optimal_k}")