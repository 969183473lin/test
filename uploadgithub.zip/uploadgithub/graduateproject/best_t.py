import numpy as np
import cv2
import matplotlib.pyplot as plt

def compute_rarity_map(image_path, k=5):
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    image = image.astype(np.float32)

    # 获取图像尺寸
    Xsize, Ysize = image.shape

    # 将图像展平为一维数组
    Z = image.reshape((-1, 1))
    Z = np.float32(Z)

    # 应用K-Means聚类
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 0.5)
    ret, label, center = cv2.kmeans(Z, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)

    # 将聚类结果重新 reshape 为图像形状
    center = np.uint8(center)
    res = center[label.flatten()]
    clustered_image = res.reshape((image.shape))

    # 计算每个簇的像素数量
    cluster_counts = np.bincount(label.flatten())

    # 计算每个簇的稀有度
    cluster_rarity = 1.0 / cluster_counts
    cluster_rarity /= np.sum(cluster_rarity)

    # 生成稀有度图
    rarity_map = np.zeros((Xsize, Ysize))
    for i in range(Xsize):
        for j in range(Ysize):
            cluster_index = label[i * Ysize + j]
            cluster_index = cluster_index.item()  # 使用 item() 替代 asscalar()
            rarity_map[i, j] = cluster_rarity[cluster_index]

    # 归一化稀有度图
    rarity_map = (rarity_map - np.min(rarity_map)) / (np.max(rarity_map) - np.min(rarity_map))

    return rarity_map

def explore_thresholds(rarity_map, thresholds):
    target_areas = []

    for threshold in thresholds:
        binary_map = rarity_map > threshold
        target_area = np.sum(binary_map)
        target_areas.append(target_area)

    return target_areas

def plot_thresholds(thresholds, target_areas):
    plt.plot(thresholds, target_areas, marker='o', linestyle='-', color='b')
    plt.title('Exploring Best Threshold')
    plt.xlabel('Threshold')
    plt.ylabel('Target Area')
    plt.grid(True)
    plt.show()

# 调用函数
image_path = 'D://graduateproject//picture//15.png'
rarity_map = compute_rarity_map(image_path, k=5)
thresholds = np.linspace(0, 1, 100)  # 生成100个阈值，从0到1
target_areas = explore_thresholds(rarity_map, thresholds)
plot_thresholds(thresholds, target_areas)