import numpy as np
import cv2


def calculate_local_std(image, win_size):
    pad = win_size // 2
    padded_image = cv2.copyMakeBorder(image, pad, pad, pad, pad, cv2.BORDER_REFLECT)
    local_mean = cv2.blur(padded_image, (win_size, win_size))
    local_mean_sq = cv2.blur(padded_image ** 2, (win_size, win_size))
    local_std = np.sqrt(local_mean_sq - local_mean ** 2)
    return local_std[pad:-pad, pad:-pad]


def compute_feature_maps(image_path):
    src = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    image = src.astype(np.float32)
    Xsize, Ysize = src.shape

    # 计算局部标准差和动态窗口大小
    local_std = calculate_local_std(image, 3)
    win_sizes = np.zeros_like(image, dtype=np.int32)
    for i in range(Xsize):
        for j in range(Ysize):
            if local_std[i, j] > 20:
                win_sizes[i, j] = 3
            elif local_std[i, j] > 10:
                win_sizes[i, j] = 5
            else:
                win_sizes[i, j] = 7

    # 计算改进的局部强度图 (imap)
    local_mean = np.zeros_like(image)
    for i in range(Xsize):
        for j in range(Ysize):
            win_size = win_sizes[i, j]
            pad = win_size // 2
            region = image[max(i - pad, 0):min(i + pad + 1, Xsize), max(j - pad, 0):min(j + pad + 1, Ysize)]
            local_mean[i, j] = np.mean(region)
    imap = image - local_mean
    imap = (imap - imap.min()) / (imap.max() - imap.min() + 1e-6)

    # 计算梯度特征图 (gmap)
    grad_x = cv2.Sobel(image, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(image, cv2.CV_32F, 0, 1, ksize=3)
    gmap = np.maximum(np.abs(grad_x), np.abs(grad_y))
    gmap = (gmap - gmap.min()) / (gmap.max() - gmap.min() + 1e-6)

    return imap, gmap


def find_optimal_weights(image_path, threshold=0.3, step=0.05):
    # 获取特征图
    imap, gmap = compute_feature_maps(image_path)

    # 计算原始梯度幅值作为评分基准
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE).astype(np.float32)
    grad_x = cv2.Sobel(image, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(image, cv2.CV_32F, 0, 1, ksize=3)
    grad_mag = np.maximum(np.abs(grad_x), np.abs(grad_y))
    grad_mag = (grad_mag - grad_mag.min()) / (grad_mag.max() - grad_mag.min() + 1e-6)

    best_score = -np.inf
    best_iw = 0.0
    best_gw = 0.0

    # 网格搜索参数空间
    for iw in np.arange(0, 1.01, step):
        for gw in np.arange(0, 1.01, step):
            # 特征融合
            combined = iw * imap + gw * gmap
            # 二值化
            binary = combined > threshold
            # 跳过全黑结果
            if np.sum(binary) == 0:
                continue
            # 计算评分：边缘区域的平均梯度响应
            score = np.sum(grad_mag * binary) / np.sum(binary)
            # 更新最佳参数
            if score > best_score:
                best_score = score
                best_iw = iw
                best_gw = gw

    return best_iw, best_gw, best_score


# 使用示例
image_path = 'D://graduateproject//picture//9.png'
optimal_iw, optimal_gw, score = find_optimal_weights(image_path, threshold=0.3, step=0.05)
print(f"Optimal weights: imap_weight={optimal_iw:.2f}, gmap_weight={optimal_gw:.2f}")
print(f"Validation score: {score:.4f}")