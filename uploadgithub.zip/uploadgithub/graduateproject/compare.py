import numpy as np
import cv2
import matplotlib.pyplot as plt
import time

# 全局稀有度检测
def global_rarity_detection(image_path, k=5):
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    image = image.astype(np.float32)

    # 获取图像尺寸
    Xsize, Ysize = image.shape

    # 将图像展平为一维数组
    Z = image.reshape((-1, 1))
    Z = np.float32(Z)

    # 应用K-Means聚类
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 0.5)
    ret, label, center = cv2.kmeans(Z, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)

    # 将聚类结果重新 reshape 为图像形状
    center = np.uint8(center)
    res = center[label.flatten()]
    clustered_image = res.reshape((image.shape))

    # 计算每个簇的像素数量
    cluster_counts = np.bincount(label.flatten())
    # 计算每个簇的稀有度
    cluster_rarity = 1.0 / cluster_counts
    cluster_rarity /= np.sum(cluster_rarity)

    # 生成稀有度图
    rarity_map = np.zeros((Xsize, Ysize))
    for i in range(Xsize):
        for j in range(Ysize):
            cluster_index = label[i * Ysize + j]
            cluster_index = cluster_index.item()  # 使用 item() 替代 asscalar()
            rarity_map[i, j] = cluster_rarity[cluster_index]  # 归一化稀有度图
    rarity_map = ((rarity_map - np.min(rarity_map)) /
                  (np.max(rarity_map) - np.min(rarity_map)))
    max_rarity_index = np.argmax(cluster_rarity)  # 找到稀有度最大的簇的索引
    # 生成二值图，只保留稀有度最大的簇
    binary_map = np.zeros((Xsize, Ysize), dtype=np.uint8)
    for i in range(Xsize):
        for j in range(Ysize):
            cluster_index = label[i * Ysize + j].item()
            if cluster_index == max_rarity_index:
                binary_map[i, j] = 1  # 目标区域设置为1（白色）

    return binary_map

# 局部特征和梯度强度检测
def adaptive_lig_detection(image_path, min_win_size=3, max_win_size=7, imap_weight=0.28, gmap_weight=0.2, threshold=0.32):
    # 读取图像并转换为浮点型
    src = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    image = src.astype(np.float32)

    # 图像尺寸
    Xsize, Ysize = src.shape

    # 初始化特征图
    gmap = np.zeros_like(image)
    imap = np.zeros_like(image)

    # ========== 自适应窗口大小选择 ==========
    # 计算局部标准差
    local_std = calculate_local_std(image, win_size=3)  # 使用3x3窗口计算局部标准差

    # 根据局部标准差动态选择窗口大小
    win_sizes = np.zeros_like(image, dtype=np.int32)
    for i in range(Xsize):
        for j in range(Ysize):
            if local_std[i, j] > 20:  # 高标准差区域，使用小窗口
                win_sizes[i, j] = min_win_size
            elif local_std[i, j] > 10:  # 中等标准差区域，使用中等窗口
                win_sizes[i, j] = 5
            else:  # 低标准差区域，使用大窗口
                win_sizes[i, j] = max_win_size

    # ========== 改进的局部强度计算 ==========
    # 使用动态窗口计算局部均值
    local_mean = np.zeros_like(image)
    for i in range(Xsize):
        for j in range(Ysize):
            win_size = win_sizes[i, j]
            pad = win_size // 2
            # 提取局部区域
            region = image[max(i - pad, 0):min(i + pad + 1, Xsize), max(j - pad, 0):min(j + pad + 1, Ysize)]
            local_mean[i, j] = np.mean(region)
    imap = image - local_mean

    # ========== 梯度特征计算（优化为Sobel算子） ==========
    grad_x = cv2.Sobel(image, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(image, cv2.CV_32F, 0, 1, ksize=3)
    gmap = np.maximum(np.abs(grad_x), np.abs(grad_y))

    # ========== 特征后处理 ==========
    # 归一化处理
    imap = (imap - imap.min()) / (imap.max() - imap.min() + 1e-6)
    gmap = (gmap - gmap.min()) / (gmap.max() - gmap.min() + 1e-6)

    # 特征融合与阈值分割
    combined_map = imap_weight * imap + gmap_weight * gmap
    binary_map = combined_map > threshold

    return binary_map

# 计算局部标准差的辅助函数
def calculate_local_std(image, win_size):
    """
    计算图像的局部标准差
    :param image: 输入图像
    :param win_size: 窗口大小
    :return: 局部标准差图
    """
    pad = win_size // 2
    padded_image = cv2.copyMakeBorder(image, pad, pad, pad, pad, cv2.BORDER_REFLECT)
    local_mean = cv2.blur(padded_image, (win_size, win_size))
    local_mean_sq = cv2.blur(padded_image ** 2, (win_size, win_size))
    local_std = np.sqrt(local_mean_sq - local_mean ** 2)
    return local_std[pad:-pad, pad:-pad]

# 基于局部对比度的方法（LCM）
def lcm_detection(image):
    """基于局部对比度的方法"""
    # 计算局部对比度
    local_mean = cv2.blur(image, (15, 15))
    local_std = cv2.blur(image**2, (15, 15)) - local_mean**2
    local_std = np.sqrt(np.maximum(local_std, 0))
    # 对比度增强
    contrast_map = (image - local_mean) / (local_std + 1e-6)
    # 二值化
    binary_map = contrast_map > np.mean(contrast_map) * 2
    return binary_map.astype(np.uint8) * 255

# 对比函数
def compare_algorithms(image_path):
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    image = image.astype(np.float32)

    # 运行算法
    results = {}
    start_time = time.time()
    results['Global Rarity'] = global_rarity_detection(image_path)
    results['Global Rarity Time'] = time.time() - start_time

    start_time = time.time()
    results['Adaptive LIG'] = adaptive_lig_detection(image_path)
    results['Adaptive LIG Time'] = time.time() - start_time

    start_time = time.time()
    results['LCM'] = lcm_detection(image)
    results['LCM Time'] = time.time() - start_time

    # 可视化结果
    plt.figure(figsize=(15, 10))
    plt.subplot(2, 3, 1), plt.imshow(image, cmap='gray'), plt.title('Original Image')
    plt.subplot(2, 3, 2), plt.imshow(results['Global Rarity'], cmap='gray'), plt.title('Global Rarity')
    plt.subplot(2, 3, 3), plt.imshow(results['Adaptive LIG'], cmap='gray'), plt.title('Adaptive LIG')
    plt.subplot(2, 3, 4), plt.imshow(results['LCM'], cmap='gray'), plt.title('LCM')
    plt.tight_layout()
    plt.show()

    # 打印运行时间
    print("Running Times:")
    for key, value in results.items():
        if 'Time' in key:
            print(f"{key}: {value:.4f}s")

# 调用函数
image_path = 'D://graduateproject//picture//15.png'
compare_algorithms(image_path)