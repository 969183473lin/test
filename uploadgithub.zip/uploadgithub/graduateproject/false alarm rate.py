import os
import cv2
import numpy as np
from tqdm import tqdm

def calculate_local_std(image, win_size):
    pad = win_size // 2
    padded_image = cv2.copyMakeBorder(image, pad, pad, pad, pad, cv2.BORDER_REFLECT)
    local_mean = cv2.blur(padded_image, (win_size, win_size))
    local_mean_sq = cv2.blur(padded_image ** 2, (win_size, win_size))
    local_std = np.sqrt(local_mean_sq - local_mean ** 2)
    return local_std[pad:-pad, pad:-pad]

def adaptive_lig_detection(image_path, min_win_size=3, max_win_size=7, imap_weight=0.28, gmap_weight=0.2, threshold=0.29):
    src = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if src is None:
        raise FileNotFoundError(f"Image file not found: {image_path}")
    Xsize, Ysize = src.shape
    image = src.astype(np.float32)

    local_std = calculate_local_std(image, win_size=3)
    win_sizes = np.zeros_like(local_std, dtype=np.int32)
    for i in range(Xsize):
        for j in range(Ysize):
            if local_std[i, j] > 20:
                win_sizes[i, j] = min_win_size
            elif local_std[i, j] > 10:
                win_sizes[i, j] = 5
            else:
                win_sizes[i, j] = max_win_size

    local_mean = np.zeros_like(image)
    for i in range(Xsize):
        for j in range(Ysize):
            win_size = win_sizes[i, j]
            pad = win_size // 2
            region = image[max(i - pad, 0):min(i + pad + 1, Xsize), max(j - pad, 0):min(j + pad + 1, Ysize)]
            local_mean[i, j] = np.mean(region)
    imap = image - local_mean

    grad_x = cv2.Sobel(image, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(image, cv2.CV_32F, 0, 1, ksize=3)
    gmap = np.maximum(np.abs(grad_x), np.abs(grad_y))

    imap = (imap - imap.min()) / (imap.max() - imap.min() + 1e-6)
    gmap = (gmap - gmap.min()) / (gmap.max() - gmap.min() + 1e-6)

    combined_map = imap_weight * imap + gmap_weight * gmap

    return combined_map

def global_rarity_detection(image, k=4):
    image = image.astype(np.float32)
    Xsize, Ysize = image.shape
    Z = image.reshape((-1, 1))
    Z = np.float32(Z)
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.01)
    ret, label, center = cv2.kmeans(Z, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)

    center = np.uint8(center)
    res = center[label.flatten()]
    clustered_image = res.reshape((image.shape))

    cluster_counts = np.bincount(label.flatten())
    cluster_rarity = 1.0 / cluster_counts
    cluster_rarity /= np.sum(cluster_rarity)

    rarity_map = np.zeros((Xsize, Ysize))
    for i in range(Xsize):
        for j in range(Ysize):
            cluster_index = label[i * Ysize + j].item()
            rarity_map[i, j] = cluster_rarity[cluster_index]
    rarity_map = ((rarity_map - rarity_map.min()) / (rarity_map.max() - rarity_map.min()))

    return rarity_map

def combined_detection(image_path, min_win_size=3, max_win_size=7, imap_weight=0.28, gmap_weight=0.2, k=20):
    # 局部特征检测
    local_combined = adaptive_lig_detection(image_path, min_win_size, max_win_size, imap_weight, gmap_weight)

    # 全局稀有度检测
    global_rarity = global_rarity_detection(local_combined * 255, k)

    # 确保特征图值在合理范围内
    local_combined = (local_combined - local_combined.min()) / (local_combined.max() - local_combined.min() + 1e-6)
    global_rarity = (global_rarity - global_rarity.min()) / (global_rarity.max() - global_rarity.min() + 1e-6)

    # 结果融合
    final_result = np.logical_and(local_combined > 0.3, global_rarity > 0.4).astype(np.uint8)

    return final_result

def calculate_false_alarm_rate(detection_result, ground_truth):
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    false_alarms = np.sum(detection_result & np.logical_not(ground_truth))
    non_target_areas = np.sum(np.logical_not(ground_truth))

    if non_target_areas == 0:
        return float('inf')  # 避免除以零的情况

    false_alarm_rate = false_alarms / non_target_areas
    return false_alarm_rate

def calculate_average_false_alarm_rate(image_dir, mask_dir, detection_func, **kwargs):
    false_alarm_rates = []
    image_files = [f for f in os.listdir(image_dir) if f.endswith(('.png', '.jpg', '.jpeg'))]

    # 使用 tqdm 显示进度条
    for image_file in tqdm(image_files, desc='Processing images'):
        image_path = os.path.join(image_dir, image_file)
        mask_path = os.path.join(mask_dir, image_file)

        # 检查标注文件是否存在
        if not os.path.exists(mask_path):
            print(f"标注文件不存在: {mask_path}")
            continue

        # 检测结果
        detection_result = detection_func(image_path, **kwargs)

        # 标注数据
        ground_truth = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        if ground_truth is None:
            print(f"无法读取标注文件: {mask_path}")
            continue
        ground_truth = ground_truth > 0  # 转换为二值图

        # 计算虚警率
        false_alarm_rate = calculate_false_alarm_rate(detection_result, ground_truth)
        false_alarm_rates.append(false_alarm_rate)

    # 计算平均虚警率
    if not false_alarm_rates:
        return float('nan')

    average_false_alarm_rate = np.mean(false_alarm_rates)
    return average_false_alarm_rate

# 使用示例
image_dir = 'D://graduateproject//picture'  # 图像文件夹路径
mask_dir = 'D://graduateproject//masks'     # 标注文件夹路径

# 计算平均虚警率
average_false_alarm_rate = calculate_average_false_alarm_rate(image_dir, mask_dir, combined_detection)
print(f"平均虚警率: {average_false_alarm_rate:.4f}")