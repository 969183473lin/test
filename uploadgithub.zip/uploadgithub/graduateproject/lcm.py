import numpy as np
import cv2
import os


def lcm_detection(image, window_size=15, threshold_scale=2.0):
    """
    基于局部对比度的方法（LCM）
    :param image: 输入图像（灰度图，uint8 类型）
    :param window_size: 局部邻域窗口大小（默认15x15）
    :param threshold_scale: 对比度阈值缩放因子（默认2.0）
    :return: 二值图（目标区域为255，背景为0）
    """
    # 将图像转换为浮点型
    image = image.astype(np.float32)

    # 计算局部均值和局部标准差
    local_mean = cv2.blur(image, (window_size, window_size))
    local_mean_sq = cv2.blur(image ** 2, (window_size, window_size))
    local_std = np.sqrt(np.maximum(local_mean_sq - local_mean ** 2, 0))

    # 计算局部对比度
    epsilon = 1e-6  # 避免除零错误
    contrast_map = (image - local_mean) / (local_std + epsilon)

    # 自适应阈值分割
    threshold = np.mean(contrast_map) * threshold_scale
    binary_map = (contrast_map > threshold).astype(np.uint8) * 255

    return binary_map, contrast_map


def calculate_precision(detection_result, ground_truth):
    """
    计算精确度
    :param detection_result: 检测结果（二值图）
    :param ground_truth: 标注数据（二值图）
    :return: 精确度
    """
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    true_positives = np.logical_and(detection_result, ground_truth)
    detected_positives = detection_result

    # 检查 detected_positives 的总和是否为零
    if np.sum(detected_positives) == 0:
        precision = 0.0
    else:
        precision = np.sum(true_positives) / np.sum(detected_positives)

    return precision


def process_image(image_path, ground_truth_path):
    """
    处理单张图像并计算精确度
    :param image_path: 图像路径
    :param ground_truth_path: 标注数据路径
    :return: 精确度
    """
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"图像文件未找到: {image_path}")

    # LCM 检测
    binary_map, _ = lcm_detection(image)

    # 读取标注数据
    ground_truth = cv2.imread(ground_truth_path, cv2.IMREAD_GRAYSCALE)
    if ground_truth is None:
        raise FileNotFoundError(f"标注数据文件未找到: {ground_truth_path}")
    ground_truth = ground_truth > 0  # 转换为二值图

    # 计算精确度
    precision = calculate_precision(binary_map, ground_truth)
    return precision


def batch_process_images(image_folder, ground_truth_folder):
    """
    批量处理图像并计算平均精确度
    :param image_folder: 图像文件夹路径
    :param ground_truth_folder: 标注数据文件夹路径
    :return: 平均精确度
    """
    # 获取图像文件和标注文件列表
    image_files = sorted(os.listdir(image_folder))
    ground_truth_files = sorted(os.listdir(ground_truth_folder))

    # 检查图像文件和标注文件数量是否匹配
    if len(image_files) != len(ground_truth_files):
        raise ValueError("图像文件和标注文件数量不匹配")

    # 初始化变量
    total_precision = 0.0
    processed_count = 0
    total_images = len(image_files)

    # 遍历图像和标注文件
    for img_file, gt_file in zip(image_files, ground_truth_files):
        if not img_file.endswith('.png') or not gt_file.endswith('.png'):
            continue

        image_path = os.path.join(image_folder, img_file)
        ground_truth_path = os.path.join(ground_truth_folder, gt_file)

        try:
            # 计算单张图像的精确度
            precision = process_image(image_path, ground_truth_path)
            total_precision += precision
            processed_count += 1
            print(f"已处理 {processed_count} 张图像，共 {total_images} 张")
        except Exception as e:
            print(f"处理图像 {img_file} 时出错: {e}")

    # 计算平均精确度
    average_precision = total_precision / total_images
    return average_precision


# 使用示例
image_folder = 'D://graduateproject//picture'
ground_truth_folder = 'D://graduateproject//masks'

#average_precision = batch_process_images(image_folder, ground_truth_folder)
#print(f"平均精确度: {average_precision:.4f}")