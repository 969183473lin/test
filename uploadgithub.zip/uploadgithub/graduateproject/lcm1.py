import numpy as np
import cv2
import os


def lcm_detection(image, window_size=15, threshold_scale=2.0):
    """
    基于局部对比度的方法（LCM）
    :param image: 输入图像（灰度图，uint8 类型）
    :param window_size: 局部邻域窗口大小（默认15x15）
    :param threshold_scale: 对比度阈值缩放因子（默认2.0）
    :return: 二值图（目标区域为255，背景为0）
    """
    # 将图像转换为浮点型
    image = image.astype(np.float32)

    # 计算局部均值和局部标准差
    local_mean = cv2.blur(image, (window_size, window_size))
    local_mean_sq = cv2.blur(image ** 2, (window_size, window_size))
    local_std = np.sqrt(np.maximum(local_mean_sq - local_mean ** 2, 0))

    # 计算局部对比度
    epsilon = 1e-6  # 避免除零错误
    contrast_map = (image - local_mean) / (local_std + epsilon)

    # 自适应阈值分割
    threshold = np.mean(contrast_map) * threshold_scale
    binary_map = (contrast_map > threshold).astype(np.uint8) * 255

    return binary_map, contrast_map


def calculate_far_recall_precision(detection_result, ground_truth):
    """
    计算虚警率（FAR）、召回率（Recall）和精确率（Precision）
    :param detection_result: 检测结果（二值图）
    :param ground_truth: 标注数据（二值图）
    :return: 虚警率 (FAR), 召回率 (Recall), 精确率 (Precision)
    """
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    # 计算真正例 (TP)
    TP = np.logical_and(detection_result, ground_truth).sum()

    # 计算假正例 (FP)
    FP = np.logical_and(detection_result, ~ground_truth).sum()

    # 计算假负例 (FN)
    FN = np.logical_and(~detection_result, ground_truth).sum()

    # 计算背景像素总数 (BG)
    BG = (~ground_truth).sum()

    # 计算虚警率 (FAR)
    if BG > 0:
        FAR = FP / BG
    else:
        FAR = 0.0

    # 计算召回率 (Recall)
    if (TP + FN) > 0:
        Recall = TP / (TP + FN)
    else:
        Recall = 0.0

    # 计算精确率 (Precision)
    if (TP + FP) > 0:
        Precision = TP / (TP + FP)
    else:
        Precision = 0.0

    return FAR, Recall, Precision


def process_single_image(image_path, ground_truth_path):
    """
    处理单张图像并计算指标
    :param image_path: 图像路径
    :param ground_truth_path: 标注数据路径
    """
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"图像文件未找到: {image_path}")

    # LCM 检测
    binary_map, _ = lcm_detection(image)

    # 读取标注数据
    ground_truth = cv2.imread(ground_truth_path, cv2.IMREAD_GRAYSCALE)
    if ground_truth is None:
        raise FileNotFoundError(f"标注数据文件未找到: {ground_truth_path}")
    ground_truth = ground_truth > 0  # 转换为二值图

    # 确保检测结果和标注数据的大小一致
    if binary_map.shape != ground_truth.shape:
        ground_truth = cv2.resize(ground_truth.astype(np.uint8), (binary_map.shape[1], binary_map.shape[0]))

    # 计算指标
    FAR, Recall, Precision = calculate_far_recall_precision(binary_map, ground_truth)

    # 输出结果
    print(f"虚警率 (FAR): {FAR:.4f}")
    print(f"召回率 (Recall): {Recall:.4f}")
    print(f"精确率 (Precision): {Precision:.4f}")
    return FAR, Recall, Precision

# 使用示例
image_path = 'D://graduateproject//picture//000025.png'  # 输入图像路径
ground_truth_path = 'D://graduateproject//masks//000025.png'  # 真实标注图路径

process_single_image(image_path, ground_truth_path)