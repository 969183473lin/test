import numpy as np
import cv2
import matplotlib.pyplot as plt
import time  # 导入时间模块

def global_rarity_detection(image_path, k=5):
    # 记录开始时间
    start_time = time.time()

    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    image = image.astype(np.float32)

    # 获取图像尺寸
    Xsize, Ysize = image.shape

    # 将图像展平为一维数组
    Z = image.reshape((-1, 1))
    Z = np.float32(Z)

    # 应用K-Means聚类
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.1)
    ret, label, center = cv2.kmeans(Z, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)

    # 将聚类结果重新 reshape 为图像形状
    center = np.uint8(center)
    res = center[label.flatten()]
    clustered_image = res.reshape((image.shape))

    # 计算每个簇的像素数量
    cluster_counts = np.bincount(label.flatten())
    # 输出每个簇的像素数量
    print("Cluster Pixel Counts:")
    for i in range(k):
        print(f"Cluster {i}: {cluster_counts[i]} pixels")
    # 计算每个簇的稀有度
    cluster_rarity = 1.0 / cluster_counts
    cluster_rarity /= np.sum(cluster_rarity)
    # 输出每个簇的稀有度
    print("Cluster Rarities:")
    for i in range(k):
        print(f"Cluster {i}: {cluster_rarity[i]}")

    # 生成稀有度图
    rarity_map = np.zeros((Xsize, Ysize))
    for i in range(Xsize):
        for j in range(Ysize):
            cluster_index = label[i * Ysize + j]
            cluster_index = cluster_index.item()  # 使用 item() 替代 asscalar()
            rarity_map[i, j] = cluster_rarity[cluster_index]  # 归一化稀有度图
    rarity_map = ((rarity_map - np.min(rarity_map)) /
                  (np.max(rarity_map) - np.min(rarity_map)))
    max_rarity_index = np.argmax(cluster_rarity)  # 找到稀有度最大的簇的索引
    # 生成二值图，只保留稀有度最大的簇
    binary_map = np.zeros((Xsize, Ysize), dtype=np.uint8)
    for i in range(Xsize):
        for j in range(Ysize):
            cluster_index = label[i * Ysize + j].item()
            if cluster_index == max_rarity_index:
                binary_map[i, j] = 1  # 目标区域设置为1（白色）

    # 记录结束时间
    end_time = time.time()

    # 计算运行时间
    run_time = end_time - start_time
    print(f"目标检测运行时间: {run_time:.4f} 秒")

    # 显示结果
    plt.figure()
    plt.subplot(2, 2, 1), plt.imshow(image, cmap='gray'), plt.title('Original Image')
    plt.subplot(2, 2, 2), plt.imshow(clustered_image, cmap='gray'), plt.title('Clustered Image')
    plt.subplot(2, 2, 3), plt.imshow(rarity_map, cmap='gray'), plt.title('Rarity Map')
    plt.subplot(2, 2, 4), plt.imshow(binary_map, cmap='gray'), plt.title('Binary Map (Max Rarity Cluster)')
    plt.show()

    return binary_map

# 调用函数
image_path = 'D://graduateproject//picture//000015.png'
binary_map = global_rarity_detection(image_path, k=15)