import numpy as np
import cv2
import os


def max_median_detection(image, kernel_size=15):
    """
    Max-Median 滤波检测小目标
    :param image: 输入图像（灰度图，uint8 类型）
    :param kernel_size: 滤波核大小
    :return: 二值图（目标区域为255，背景为0）
    """
    # 中值滤波
    median = cv2.medianBlur(image, kernel_size)
    # 最大值滤波
    max_filtered = cv2.dilate(image, np.ones((kernel_size, kernel_size), np.uint8))
    # 计算差异
    diff = cv2.subtract(max_filtered, median)
    # 二值化
    _, binary_map = cv2.threshold(diff, 50, 255, cv2.THRESH_BINARY)
    return binary_map


def calculate_recall(detection_result, ground_truth):
    """
    计算召回率
    :param detection_result: 检测结果（二值图）
    :param ground_truth: 标注数据（二值图）
    :return: 召回率
    """
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    true_positives = np.logical_and(detection_result, ground_truth)
    actual_positives = ground_truth

    recall = np.sum(true_positives) / np.sum(actual_positives)

    return recall


def process_image(image_path, ground_truth_path):
    """
    处理单张图像并计算召回率
    :param image_path: 图像路径
    :param ground_truth_path: 标注数据路径
    :return: 召回率
    """
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"图像文件未找到: {image_path}")

    # Max-Median 检测
    binary_map = max_median_detection(image)

    # 读取标注数据
    ground_truth = cv2.imread(ground_truth_path, cv2.IMREAD_GRAYSCALE)
    if ground_truth is None:
        raise FileNotFoundError(f"标注数据文件未找到: {ground_truth_path}")
    ground_truth = ground_truth > 0  # 转换为二值图

    # 计算召回率
    recall = calculate_recall(binary_map, ground_truth)
    return recall


def batch_process_images(image_folder, ground_truth_folder):
    """
    批量处理图像并计算平均召回率
    :param image_folder: 图像文件夹路径
    :param ground_truth_folder: 标注数据文件夹路径
    :return: 平均召回率
    """
    # 获取图像文件和标注文件列表
    image_files = sorted(os.listdir(image_folder))
    ground_truth_files = sorted(os.listdir(ground_truth_folder))

    # 检查图像文件和标注文件数量是否匹配
    if len(image_files) != len(ground_truth_files):
        raise ValueError("图像文件和标注文件数量不匹配")

    # 初始化变量
    total_recall = 0.0
    processed_count = 0
    total_images = len(image_files)

    # 遍历图像和标注文件
    for img_file, gt_file in zip(image_files, ground_truth_files):
        if not img_file.endswith('.png') or not gt_file.endswith('.png'):
            continue

        image_path = os.path.join(image_folder, img_file)
        ground_truth_path = os.path.join(ground_truth_folder, gt_file)

        try:
            # 计算单张图像的召回率
            recall = process_image(image_path, ground_truth_path)
            total_recall += recall
            processed_count += 1
            print(f"已处理 {processed_count} 张图像，共 {total_images} 张")
        except Exception as e:
            print(f"处理图像 {img_file} 时出错: {e}")

    # 计算平均召回率
    average_recall = total_recall / total_images
    return average_recall


# 使用示例
image_folder = 'D://graduateproject//picture'
ground_truth_folder = 'D://graduateproject//masks'

#average_recall = batch_process_images(image_folder, ground_truth_folder)
#print(f"平均召回率: {average_recall:.4f}")