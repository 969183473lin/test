import numpy as np
import cv2
import matplotlib.pyplot as plt
import time
from sklearn.mixture import GaussianMixture

def calculate_local_std(image, win_size):
    pad = win_size // 2
    padded_image = cv2.copyMakeBorder(image, pad, pad, pad, pad, cv2.BORDER_REFLECT)
    local_mean = cv2.blur(padded_image, (win_size, win_size))
    local_mean_sq = cv2.blur(padded_image ** 2, (win_size, win_size))
    local_std = np.sqrt(local_mean_sq - local_mean ** 2)
    return local_std[pad:-pad, pad:-pad]

def adaptive_lig_detection(image_path, min_win_size=3, max_win_size=7, imap_weight=0.28, gmap_weight=0.2):
    start_time = time.time()
    src = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if src is None:
        raise FileNotFoundError(f"Image file not found: {image_path}")
    Xsize, Ysize = src.shape
    image = src.astype(np.float32)

    local_std = calculate_local_std(image, win_size=3)
    win_sizes = np.zeros_like(local_std, dtype=np.int32)
    for i in range(Xsize):
        for j in range(Ysize):
            if local_std[i, j] > 20:
                win_sizes[i, j] = min_win_size
            elif local_std[i, j] > 10:
                win_sizes[i, j] = 5
            else:
                win_sizes[i, j] = max_win_size

    local_mean = np.zeros_like(image)
    for i in range(Xsize):
        for j in range(Ysize):
            win_size = win_sizes[i, j]
            pad = win_size // 2
            region = image[max(i - pad, 0):min(i + pad + 1, Xsize), max(j - pad, 0):min(j + pad + 1, Ysize)]
            local_mean[i, j] = np.mean(region)
    imap = image - local_mean

    edges = cv2.Canny(image.astype(np.uint8), 50, 150)
    grad_x = cv2.Sobel(image, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(image, cv2.CV_32F, 0, 1, ksize=3)
    gmap = np.maximum(np.abs(grad_x), np.abs(grad_y))
    gmap[edges == 0] = 0

    imap = (imap - imap.min()) / (imap.max() - imap.min() + 1e-6)
    gmap = (gmap - gmap.min()) / (gmap.max() - gmap.min() + 1e-6)

    combined_map = imap_weight * imap + gmap_weight * gmap
    combined_map = cv2.GaussianBlur(combined_map, (3, 3), 0)

    end_time = time.time()
    run_time = end_time - start_time
    print(f"局部特征检测运行时间: {run_time:.4f} 秒")

    return combined_map

def enhance_local_combined_map(combined_map, background_window_size=15):
    start_time = time.time()
    background_mean = cv2.blur(combined_map, (background_window_size, background_window_size))
    enhanced_map = combined_map - background_mean
    enhanced_map = np.clip(enhanced_map, 0, 1)

    end_time = time.time()
    run_time = end_time - start_time
    print(f"增强运行时间: {run_time:.4f} 秒")

    return enhanced_map

def calculate_global_rarity_multiscale(enhanced_map, scales=[3, 5, 7]):
    start_time = time.time()
    multiscale_features = []

    for scale in scales:
        blurred = cv2.GaussianBlur(enhanced_map, (scale, scale), 0)
        multiscale_features.append(blurred)

    multiscale_features = np.array(multiscale_features)
    feature_variances = np.var(multiscale_features, axis=0)

    Z = feature_variances.reshape((-1, 1))
    gmm = GaussianMixture(n_components=3, random_state=42)
    gmm.fit(Z)
    probabilities = np.exp(gmm.score_samples(Z))
    probabilities = probabilities / probabilities.max()
    rarity_scores = 1 - probabilities
    rarity_map = rarity_scores.reshape(feature_variances.shape)

    end_time = time.time()
    run_time = end_time - start_time
    print(f"基于多尺度特征的全局稀有度计算运行时间: {run_time:.4f} 秒")

    return rarity_map

def fuse_and_normalize(local_map, global_map, alpha=0.1):
    fused_map = alpha * local_map + (1 - alpha) * global_map
    fused_map = (fused_map - fused_map.min()) / (fused_map.max() - fused_map.min() + 1e-6)
    return fused_map

def combined_detection_multiscale(image_path, scales=[3, 5, 7], alpha=0.1):
    start_time = time.time()

    local_combined = adaptive_lig_detection(image_path)
    enhanced_map = enhance_local_combined_map(local_combined)
    global_rarity_map = calculate_global_rarity_multiscale(enhanced_map, scales)
    fused_map = fuse_and_normalize(enhanced_map, global_rarity_map, alpha)

    src = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    plt.figure(figsize=(18, 10))
    plt.subplot(1, 5, 1), plt.imshow(src, cmap='gray'), plt.title('Original Image')
    plt.subplot(1, 5, 2), plt.imshow(local_combined, cmap='gray'), plt.title('Local Combined Map')
    plt.subplot(1, 5, 3), plt.imshow(enhanced_map, cmap='gray'), plt.title('Enhanced Map')
    plt.subplot(1, 5, 4), plt.imshow(global_rarity_map, cmap='gray'), plt.title('Global Rarity Map (Multiscale)')
    plt.subplot(1, 5, 5), plt.imshow(fused_map, cmap='gray'), plt.title('Fused Salience Map')
    plt.tight_layout()
    plt.show()

    end_time = time.time()
    total_run_time = end_time - start_time
    print(f"基于多尺度特征的总运行时间: {total_run_time:.4f} 秒")

    return fused_map

def calculate_false_alarm_rate(detection_result, ground_truth):
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    false_alarms = np.sum(detection_result & np.logical_not(ground_truth))
    non_target_areas = np.sum(np.logical_not(ground_truth))

    if non_target_areas == 0:
        return float('inf')

    false_alarm_rate = false_alarms / non_target_areas
    return false_alarm_rate

def calculate_recall(detection_result, ground_truth):
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    true_positives = np.sum(detection_result & ground_truth)
    actual_targets = np.sum(ground_truth)

    if actual_targets == 0:
        return float('inf')

    recall = true_positives / actual_targets
    return recall

def calculate_precision(detection_result, ground_truth):
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    true_positives = np.sum(detection_result & ground_truth)
    detected_areas = np.sum(detection_result)

    if detected_areas == 0:
        return float('inf')

    precision = true_positives / detected_areas
    return precision

if __name__ == "__main__":
    image_path = 'D://graduateproject//picture//000002.png'
    ground_truth_path = 'D://graduateproject//masks//000002.png'

    fused_map = combined_detection_multiscale(image_path)

    ground_truth = cv2.imread(ground_truth_path, cv2.IMREAD_GRAYSCALE)
    if ground_truth is None:
        raise FileNotFoundError(f"标注数据文件未找到: {ground_truth_path}")
    ground_truth = ground_truth > 0

    threshold = 0.1
    detection_result = fused_map > threshold

    false_alarm_rate = calculate_false_alarm_rate(detection_result, ground_truth)
    print(f"虚警率: {false_alarm_rate:.4f}")

    recall = calculate_recall(detection_result, ground_truth)
    print(f"召回率: {recall:.4f}")

    precision = calculate_precision(detection_result, ground_truth)
    print(f"精确度: {precision:.4f}")




