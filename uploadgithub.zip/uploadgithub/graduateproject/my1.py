import numpy as np
import cv2
import matplotlib.pyplot as plt
import time
from sklearn.mixture import GaussianMixture


def calculate_local_std(image, win_size):
    """
    计算局部标准差
    :param image: 输入图像（浮点型）
    :param win_size: 窗口大小
    :return: 局部标准差图
    """
    pad = win_size // 2
    padded_image = cv2.copyMakeBorder(image, pad, pad, pad, pad, cv2.BORDER_REFLECT)
    local_mean = cv2.blur(padded_image, (win_size, win_size))
    local_mean_sq = cv2.blur(padded_image ** 2, (win_size, win_size))
    local_std = np.sqrt(local_mean_sq - local_mean ** 2)
    return local_std[pad:-pad, pad:-pad]


def adaptive_lig_detection(image):
    """
    自适应局部特征检测
    :param image: 输入图像（浮点型）
    :return: 综合特征图
    """
    start_time = time.time()
    Xsize, Ysize = image.shape

    local_std = calculate_local_std(image, win_size=3)
    win_sizes = np.zeros_like(local_std, dtype=np.int32)
    for i in range(Xsize):
        for j in range(Ysize):
            if local_std[i, j] > 20:
                win_sizes[i, j] = 3
            elif local_std[i, j] > 10:
                win_sizes[i, j] = 5
            else:
                win_sizes[i, j] = 7

    local_mean = np.zeros_like(image)
    for i in range(Xsize):
        for j in range(Ysize):
            win_size = win_sizes[i, j]
            pad = win_size // 2
            region = image[max(i - pad, 0):min(i + pad + 1, Xsize), max(j - pad, 0):min(j + pad + 1, Ysize)]
            local_mean[i, j] = np.mean(region)
    imap = image - local_mean

    edges = cv2.Canny(image.astype(np.uint8), 50, 150)
    grad_x = cv2.Sobel(image, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(image, cv2.CV_32F, 0, 1, ksize=3)
    gmap = np.maximum(np.abs(grad_x), np.abs(grad_y))
    gmap[edges == 0] = 0

    imap = (imap - imap.min()) / (imap.max() - imap.min() + 1e-6)
    gmap = (gmap - gmap.min()) / (gmap.max() - gmap.min() + 1e-6)

    combined_map = 0.28 * imap + 0.2 * gmap
    combined_map = cv2.GaussianBlur(combined_map, (3, 3), 0)

    end_time = time.time()
    run_time = end_time - start_time
    print(f"局部特征检测运行时间: {run_time:.4f} 秒")

    return combined_map


def enhance_local_combined_map(combined_map):
    """
    增强局部综合特征图
    :param combined_map: 综合特征图
    :return: 增强后的特征图
    """
    start_time = time.time()
    background_mean = cv2.blur(combined_map, (15, 15))
    enhanced_map = combined_map - background_mean
    enhanced_map = np.clip(enhanced_map, 0, 1)

    end_time = time.time()
    run_time = end_time - start_time
    print(f"增强运行时间: {run_time:.4f} 秒")

    return enhanced_map


def calculate_global_rarity_multiscale(enhanced_map):
    """
    计算全局稀有度（多尺度特征）
    :param enhanced_map: 增强后的特征图
    :return: 全局稀有度图
    """
    start_time = time.time()
    scales = [3, 5, 7]
    multiscale_features = []

    for scale in scales:
        blurred = cv2.GaussianBlur(enhanced_map, (scale, scale), 0)
        multiscale_features.append(blurred)

    multiscale_features = np.array(multiscale_features)
    feature_variances = np.var(multiscale_features, axis=0)

    Z = feature_variances.reshape((-1, 1))
    gmm = GaussianMixture(n_components=3, random_state=42)
    gmm.fit(Z)
    probabilities = np.exp(gmm.score_samples(Z))
    probabilities = probabilities / probabilities.max()
    rarity_scores = 1 - probabilities
    rarity_map = rarity_scores.reshape(feature_variances.shape)

    end_time = time.time()
    run_time = end_time - start_time
    print(f"基于多尺度特征的全局稀有度计算运行时间: {run_time:.4f} 秒")

    return rarity_map


def fuse_and_normalize(local_map, global_map):
    """
    特征融合和归一化
    :param local_map: 局部特征图
    :param global_map: 全局特征图
    :return: 融合后的特征图
    """
    fused_map = 0.1 * local_map + 0.9 * global_map
    fused_map = (fused_map - fused_map.min()) / (fused_map.max() - fused_map.min() + 1e-6)
    return fused_map


def calculate_far_recall_precision(detection_result, ground_truth):
    """
    计算虚警率、召回率和精确率
    :param detection_result: 检测结果（二值图）
    :param ground_truth: 标注数据（二值图）
    :return: 虚警率 (FAR), 召回率 (Recall), 精确率 (Precision)
    """
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    # 计算真正例 (TP)
    TP = np.logical_and(detection_result, ground_truth).sum()

    # 计算假正例 (FP)
    FP = np.logical_and(detection_result, ~ground_truth).sum()

    # 计算假负例 (FN)
    FN = np.logical_and(~detection_result, ground_truth).sum()

    # 计算背景像素总数 (BG)
    BG = (~ground_truth).sum()

    # 计算虚警率 (FAR)
    if BG > 0:
        FAR = FP / BG
    else:
        FAR = 0.0

    # 计算召回率 (Recall)
    if (TP + FN) > 0:
        Recall = TP / (TP + FN)
    else:
        Recall = 0.0

    # 计算精确率 (Precision)
    if (TP + FP) > 0:
        Precision = TP / (TP + FP)
    else:
        Precision = 0.0

    return FAR, Recall, Precision


def process_image(image_path, ground_truth_path):
    """
    处理单张图像并计算指标
    :param image_path: 输入图像路径
    :param ground_truth_path: 标注数据路径
    :return: 虚警率 (FAR), 召回率 (Recall), 精确率 (Precision)
    """
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"图像文件未找到: {image_path}")
    image = image.astype(np.float32)

    # 局部特征检测
    local_combined = adaptive_lig_detection(image)

    # 特征增强
    enhanced_map = enhance_local_combined_map(local_combined)

    # 全局稀有度计算
    global_rarity_map = calculate_global_rarity_multiscale(enhanced_map)

    # 特征融合
    fused_map = fuse_and_normalize(enhanced_map, global_rarity_map)

    # 读取标注数据
    ground_truth = cv2.imread(ground_truth_path, cv2.IMREAD_GRAYSCALE)
    if ground_truth is None:
        raise FileNotFoundError(f"标注数据文件未找到: {ground_truth_path}")
    ground_truth = ground_truth > 0  # 转换为二值图

    # 确保检测结果和标注数据的大小一致
    if fused_map.shape != ground_truth.shape:
        ground_truth = cv2.resize(ground_truth.astype(np.uint8), (fused_map.shape[1], fused_map.shape[0]))

    # 二值化检测结果
    threshold = 0.1
    detection_result = (fused_map > threshold).astype(np.uint8) * 255

    # 计算指标
    FAR, Recall, Precision = calculate_far_recall_precision(detection_result, ground_truth)

    # 输出结果
    print(f"虚警率 (FAR): {FAR:.4f}")
    print(f"召回率 (Recall): {Recall:.4f}")
    print(f"精确率 (Precision): {Precision:.4f}")

    # 可视化结果
    #plt.figure(figsize=(18, 10))
    #plt.subplot(1, 5, 1), plt.imshow(image, cmap='gray'), plt.title('Original Image')
    #plt.subplot(1, 5, 2), plt.imshow(local_combined, cmap='gray'), plt.title('Local Combined Map')
    #plt.subplot(1, 5, 3), plt.imshow(enhanced_map, cmap='gray'), plt.title('Enhanced Map')
    #plt.subplot(1, 5, 4), plt.imshow(global_rarity_map, cmap='gray'), plt.title('Global Rarity Map (Multiscale)')
    #plt.subplot(1, 5, 5), plt.imshow(fused_map, cmap='gray'), plt.title('Fused Salience Map')
    #plt.tight_layout()
    #plt.show()

    return FAR, Recall, Precision



image_path = 'D://graduateproject//picture//000025.png'  # 输入图像路径
ground_truth_path = 'D://graduateproject//masks//000025.png'  # 真实标注图路径

process_image(image_path, ground_truth_path)