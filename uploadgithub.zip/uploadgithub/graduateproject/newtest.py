import numpy as np
import cv2
import os
from pylab import mpl

# 设置中文显示字体
mpl.rcParams["font.sans-serif"] = ["SimHei"]


def LCM_computation(patch_LCM_in):
    """
    计算局部对比度 (LCM)
    :param patch_LCM_in: 输入的图像块 (patch)
    :return: C_n: 局部对比度值
    """
    row, col = patch_LCM_in.shape
    patch_LCM_in = np.array(patch_LCM_in, dtype=np.double)
    cell_size = row // 3

    # 计算中心cell的最大值
    L_n = np.max(patch_LCM_in[cell_size + 1:cell_size * 2, cell_size + 1:cell_size * 2])
    L_n_2 = L_n ** 2

    # 计算周边cell的均值
    m_1 = np.mean(patch_LCM_in[0:cell_size, 0:cell_size])
    m_2 = np.mean(patch_LCM_in[0:cell_size, cell_size:cell_size * 2])
    m_3 = np.mean(patch_LCM_in[0:cell_size, cell_size * 2:cell_size * 3])
    m_4 = np.mean(patch_LCM_in[cell_size:cell_size * 2, 0:cell_size])
    m_5 = np.mean(patch_LCM_in[cell_size:cell_size * 2, cell_size * 2:cell_size * 3])
    m_6 = np.mean(patch_LCM_in[cell_size * 2:cell_size * 3, 0:cell_size])
    m_7 = np.mean(patch_LCM_in[cell_size * 2:cell_size * 3, cell_size:cell_size * 2])
    m_8 = np.mean(patch_LCM_in[cell_size * 2:cell_size * 3, cell_size * 2:cell_size * 3])

    # 计算C_n
    m_cell = np.array(
        [L_n_2 / m_1, L_n_2 / m_2, L_n_2 / m_3, L_n_2 / m_4, L_n_2 / m_5, L_n_2 / m_6, L_n_2 / m_7, L_n_2 / m_8])
    C_n = np.min(m_cell)

    return C_n


def MLCM_computation(I_MLCM_in):
    """
    多尺度局部对比度 (MLCM) 计算
    :param I_MLCM_in: 输入图像
    :return: C_hat: 最终的多尺度对比度图
             max_margin: 边界偏移量
    """
    I_MLCM_in = np.array(I_MLCM_in, dtype=np.double)
    row, col = I_MLCM_in.shape
    scales = np.array([9, 15, 21, 27])  # patch的尺寸
    l_max = scales.shape[0]

    # Compute Cl according to Algorithm 1
    C_map_scales = np.zeros((row, col, l_max))
    for i in range(l_max):
        for j in range(0, row - scales[i] + 1):
            for k in range(0, col - scales[i] + 1):
                temp_patch = I_MLCM_in[j:j + scales[i], k:k + scales[i]]
                C_n = LCM_computation(temp_patch)
                C_map_scales[j + scales[i] // 2, k + scales[i] // 2, i] = C_n

    max_margin = (scales[-1] - 1) // 2

    # 对4种尺度对比图的共同部分取最大值
    C_hat = np.zeros((row - scales[-1] + 1, col - scales[-1] + 1))
    for i in range(row - scales[-1] + 1):
        for j in range(col - scales[-1] + 1):
            temp = np.array([
                C_map_scales[i + max_margin, j + max_margin, 0],
                C_map_scales[i + max_margin, j + max_margin, 1],
                C_map_scales[i + max_margin, j + max_margin, 2],
                C_map_scales[i + max_margin, j + max_margin, 3]
            ])
            C_hat[i, j] = np.max(temp)

    return C_hat, max_margin


def target_detection(C_hat, threshold, max_margin, I_in):
    """
    目标检测
    :param C_hat: 多尺度对比度图
    :param threshold: 阈值
    :param max_margin: 边界偏移量
    :param I_in: 输入图像
    :return: I_out: 二值化输出图
             target_pixel_num: 目标像素数
    """
    row, col = C_hat.shape
    mask = np.zeros((row, col), dtype=np.uint8)
    target_pixel_num = 0

    for i in range(row):
        for j in range(col):
            if C_hat[i, j] > threshold:
                mask[i, j] = 1
                target_pixel_num += 1

    # 将mask填入原图的中心区域
    row_in, col_in = I_in.shape
    I_out = np.zeros((row_in, col_in), dtype=np.uint8)
    I_out[max_margin:row_in - max_margin, max_margin:col_in - max_margin] = mask

    return I_out, target_pixel_num


def calculate_far_recall_precision(detection_result, ground_truth):
    """
    计算虚警率（FAR）、召回率（Recall）和精确率（Precision）
    :param detection_result: 检测结果（二值图）
    :param ground_truth: 标注数据（二值图）
    :return: 虚警率 (FAR), 召回率 (Recall), 精确率 (Precision)
    """
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    TP = np.logical_and(detection_result, ground_truth).sum()
    FP = np.logical_and(detection_result, ~ground_truth).sum()
    FN = np.logical_and(~detection_result, ground_truth).sum()
    BG = (~ground_truth).sum()

    if BG > 0:
        FAR = FP / BG
    else:
        FAR = 0.0

    if (TP + FN) > 0:
        Recall = TP / (TP + FN)
    else:
        Recall = 0.0

    if (TP + FP) > 0:
        Precision = TP / (TP + FP)
    else:
        Precision = 0.0

    return FAR, Recall, Precision


def process_image(image_path, ground_truth_path):
    """
    处理单张图像并计算指标
    :param image_path: 图像路径
    :param ground_truth_path: 标注数据路径
    :return: 虚警率 (FAR), 召回率 (Recall), 精确率 (Precision)
    """
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"图像文件未找到: {image_path}")

    # 图像大小转换为 256x256
    image = cv2.resize(image, (256, 256), interpolation=cv2.INTER_NEAREST)

    # 转为double型
    I_in = np.double(image)

    # 计算多尺度局部对比度
    C_hat, max_margin = MLCM_computation(I_in)

    # 计算均值和标准差
    mean_C_hat = np.mean(C_hat)
    std_C_hat = np.std(C_hat, ddof=1)

    # 计算阈值
    k_Th = 4
    threshold = mean_C_hat + k_Th * std_C_hat

    # 目标检测
    I_out, target_pixel_num = target_detection(C_hat, threshold, max_margin, I_in)

    # 读取标注数据
    ground_truth = cv2.imread(ground_truth_path, cv2.IMREAD_GRAYSCALE)
    if ground_truth is None:
        raise FileNotFoundError(f"标注数据文件未找到: {ground_truth_path}")
    ground_truth = ground_truth > 0  # 转换为二值图

    # 确保检测结果和标注数据的大小一致
    if I_out.shape != ground_truth.shape:
        ground_truth = cv2.resize(ground_truth.astype(np.uint8), (I_out.shape[1], I_out.shape[0]))

    # 计算指标
    FAR, Recall, Precision = calculate_far_recall_precision(I_out, ground_truth)

    # 输出结果
    print(f"目标像素数: {target_pixel_num}")
    print(f"虚警率 (FAR): {FAR:.4f}")
    print(f"召回率 (Recall): {Recall:.4f}")
    print(f"精确率 (Precision): {Precision:.4f}")

    return FAR, Recall, Precision


def batch_process_images(image_folder, ground_truth_folder):
    """
    批量处理图像并计算平均指标
    :param image_folder: 图像文件夹路径
    :param ground_truth_folder: 标注数据文件夹路径
    :return: 平均虚警率 (FAR), 平均召回率 (Recall), 平均精确率 (Precision)
    """
    # 获取图像文件和标注文件列表
    image_files = sorted(os.listdir(image_folder))
    ground_truth_files = sorted(os.listdir(ground_truth_folder))

    # 检查图像文件和标注文件数量是否匹配
    if len(image_files) != len(ground_truth_files):
        raise ValueError("图像文件和标注文件数量不匹配")

    # 初始化变量
    total_FAR = 0.0
    total_Recall = 0.0
    total_Precision = 0.0
    processed_count = 0
    total_images = len(image_files)

    # 遍历图像和标注文件
    for img_file, gt_file in zip(image_files, ground_truth_files):
        if not img_file.endswith('.png') or not gt_file.endswith('.png'):
            continue

        image_path = os.path.join(image_folder, img_file)
        ground_truth_path = os.path.join(ground_truth_folder, gt_file)

        try:
            # 计算单张图像的指标
            FAR, Recall, Precision = process_image(image_path, ground_truth_path)
            total_FAR += FAR
            total_Recall += Recall
            total_Precision += Precision
            processed_count += 1
            print(f"已处理 {processed_count} 张图像，共 {total_images} 张")
        except Exception as e:
            print(f"处理图像 {img_file} 时出错: {e}")

    # 计算平均指标
    average_FAR = total_FAR / total_images
    average_Recall = total_Recall / total_images
    average_Precision = total_Precision / total_images

    return average_FAR, average_Recall, average_Precision


def lcm_detection(image):
    """
    基于多尺度局部对比度的方法（MLCM）
    :param image: 输入图像（灰度图，uint8 类型）
    :return: 二值图（目标区域为255，背景为0）
    """
    # 图像大小转换为 256x256
    image = cv2.resize(image, (256, 256), interpolation=cv2.INTER_NEAREST)

    # 转为double型
    I_in = np.double(image)

    # 计算多尺度局部对比度
    C_hat, max_margin = MLCM_computation(I_in)

    # 计算均值和标准差
    mean_C_hat = np.mean(C_hat)
    std_C_hat = np.std(C_hat, ddof=1)

    # 计算阈值
    k_Th = 4
    threshold = mean_C_hat + k_Th * std_C_hat

    # 目标检测
    I_out, _ = target_detection(C_hat, threshold, max_margin, I_in)

    return I_out * 255, None


# 使用示例
if __name__ == "__main__":
    image_folder = 'D://graduateproject//picture'
    ground_truth_folder = 'D://graduateproject//masks'

    # 单张图像处理示例
    image_path = 'D://graduateproject//picture//000022.png'
    ground_truth_path = 'D://graduateproject//masks//000022.png'

    try:
        process_image(image_path, ground_truth_path)
    except Exception as e:
        print(f"处理图像时出错: {e}")

    # 批量处理示例
    try:
        average_FAR, average_Recall, average_Precision = batch_process_images(image_folder, ground_truth_folder)
        print(f"平均虚警率 (FAR): {average_FAR:.4f}")
        print(f"平均召回率 (Recall): {average_Recall:.4f}")
        print(f"平均精确率 (Precision): {average_Precision:.4f}")
    except Exception as e:
        print(f"批量处理图像时出错: {e}")