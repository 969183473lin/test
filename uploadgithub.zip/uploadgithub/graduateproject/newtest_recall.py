import os
import time
import numpy as np
import cv2
from pylab import mpl
from concurrent.futures import ProcessPoolExecutor

# 设置中文显示字体
mpl.rcParams["font.sans-serif"] = ["SimHei"]


def LCM_computation(patch_LCM_in):
    """
    计算局部对比度 (LCM)
    :param patch_LCM_in: 输入的图像块 (patch)
    :return: C_n: 局部对比度值
    """
    row, col = patch_LCM_in.shape
    patch_LCM_in = np.array(patch_LCM_in, dtype=np.double)
    cell_size = row // 3

    # 计算中心cell的最大值
    L_n = np.max(patch_LCM_in[cell_size + 1:cell_size * 2, cell_size + 1:cell_size * 2])
    L_n_2 = L_n ** 2

    # 计算周边cell的均值
    m_1 = np.mean(patch_LCM_in[0:cell_size, 0:cell_size])
    m_2 = np.mean(patch_LCM_in[0:cell_size, cell_size:cell_size * 2])
    m_3 = np.mean(patch_LCM_in[0:cell_size, cell_size * 2:cell_size * 3])
    m_4 = np.mean(patch_LCM_in[cell_size:cell_size * 2, 0:cell_size])
    m_5 = np.mean(patch_LCM_in[cell_size:cell_size * 2, cell_size * 2:cell_size * 3])
    m_6 = np.mean(patch_LCM_in[cell_size * 2:cell_size * 3, 0:cell_size])
    m_7 = np.mean(patch_LCM_in[cell_size * 2:cell_size * 3, cell_size:cell_size * 2])
    m_8 = np.mean(patch_LCM_in[cell_size * 2:cell_size * 3, cell_size * 2:cell_size * 3])

    # 计算C_n
    m_cell = np.array(
        [L_n_2 / m_1, L_n_2 / m_2, L_n_2 / m_3, L_n_2 / m_4, L_n_2 / m_5, L_n_2 / m_6, L_n_2 / m_7, L_n_2 / m_8])
    C_n = np.min(m_cell)

    return C_n


def MLCM_computation(I_MLCM_in):
    """
    多尺度局部对比度 (MLCM) 计算
    :param I_MLCM_in: 输入图像
    :return: C_hat: 最终的多尺度对比度图
             max_margin: 边界偏移量
    """
    I_MLCM_in = np.array(I_MLCM_in, dtype=np.double)
    row, col = I_MLCM_in.shape
    scales = np.array([9, 15, 21, 27])  # patch的尺寸
    l_max = scales.shape[0]

    # Compute Cl according to Algorithm 1
    C_map_scales = np.zeros((row, col, l_max))
    for i in range(l_max):
        scale = scales[i]
        padded_image = np.pad(I_MLCM_in, ((scale // 2, scale // 2), (scale // 2, scale // 2)), mode='constant')
        for j in range(row):
            for k in range(col):
                temp_patch = padded_image[j:j + scale, k:k + scale]
                C_n = LCM_computation(temp_patch)
                C_map_scales[j, k, i] = C_n

    max_margin = (scales[-1] - 1) // 2

    # 对4种尺度对比图的共同部分取最大值
    C_hat = np.max(C_map_scales[max_margin:row - max_margin, max_margin:col - max_margin, :], axis=2)

    return C_hat, max_margin


def target_detection(C_hat, threshold, max_margin, I_in):
    """
    目标检测
    :param C_hat: 多尺度对比度图
    :param threshold: 阈值
    :param max_margin: 边界偏移量
    :param I_in: 输入图像
    :return: I_out: 二值化输出图
             target_pixel_num: 目标像素数
    """
    row, col = C_hat.shape
    mask = (C_hat > threshold).astype(np.uint8)
    target_pixel_num = np.sum(mask)

    # 将mask填入原图的中心区域
    row_in, col_in = I_in.shape
    I_out = np.zeros((row_in, col_in), dtype=np.uint8)
    I_out[max_margin:row_in - max_margin, max_margin:col_in - max_margin] = mask

    return I_out, target_pixel_num


def calculate_far_recall_precision(detection_result, ground_truth):
    """
    计算虚警率（FAR）、召回率（Recall）和精确率（Precision）
    :param detection_result: 检测结果（二值图）
    :param ground_truth: 标注数据（二值图）
    :return: 虚警率 (FAR), 召回率 (Recall), 精确率 (Precision)
    """
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    TP = np.logical_and(detection_result, ground_truth).sum()
    FP = np.logical_and(detection_result, ~ground_truth).sum()
    FN = np.logical_and(~detection_result, ground_truth).sum()
    BG = (~ground_truth).sum()

    if BG > 0:
        FAR = FP / BG
    else:
        FAR = 0.0

    if (TP + FN) > 0:
        Recall = TP / (TP + FN)
    else:
        Recall = 0.0

    if (TP + FP) > 0:
        Precision = TP / (TP + FP)
    else:
        Precision = 0.0

    return FAR, Recall, Precision


def process_single_image(image_path, ground_truth_path, display_results=True):
    """
    处理单张图像并计算指标
    :param image_path: 图像路径
    :param ground_truth_path: 标注数据路径
    :param display_results: 是否显示结果
    :return: 虚警率 (FAR), 召回率 (Recall), 精确率 (Precision)
    """
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"图像文件未找到: {image_path}")

    # 图像大小转换为 256x256
    image = cv2.resize(image, (256, 256), interpolation=cv2.INTER_NEAREST)

    # 转为double型
    I_in = np.double(image)

    # 计算多尺度局部对比度
    C_hat, max_margin = MLCM_computation(I_in)

    # 计算均值和标准差
    mean_C_hat = np.mean(C_hat)
    std_C_hat = np.std(C_hat, ddof=1)

    # 计算阈值
    k_Th = 4
    threshold = mean_C_hat + k_Th * std_C_hat

    # 目标检测
    I_out, target_pixel_num = target_detection(C_hat, threshold, max_margin, I_in)

    # 读取标注数据
    ground_truth = cv2.imread(ground_truth_path, cv2.IMREAD_GRAYSCALE)
    if ground_truth is None:
        raise FileNotFoundError(f"标注数据文件未找到: {ground_truth_path}")
    ground_truth = ground_truth > 0  # 转换为二值图

    # 确保检测结果和标注数据的大小一致
    if I_out.shape != ground_truth.shape:
        ground_truth = cv2.resize(ground_truth.astype(np.uint8), (I_out.shape[1], I_out.shape[0]))

    # 计算指标
    FAR, Recall, Precision = calculate_far_recall_precision(I_out, ground_truth)

    # 输出结果
    if display_results:
        print(f"目标像素数: {target_pixel_num}")
        print(f"虚警率 (FAR): {FAR:.4f}")
        print(f"召回率 (Recall): {Recall:.4f}")
        print(f"精确率 (Precision): {Precision:.4f}")

        # 显示输入和输出
        import matplotlib.pyplot as plt
        plt.figure(figsize=(10, 5))
        plt.subplot(1, 2, 1)
        plt.imshow(I_in, cmap='gray', vmin=0, vmax=255)
        plt.title('原图')
        plt.axis('off')

        plt.subplot(1, 2, 2)
        plt.imshow(I_out, cmap='gray', vmin=0, vmax=1)
        plt.title('二值化输出')
        plt.axis('off')

        plt.show()

    return FAR, Recall, Precision


def evaluate_dataset(images_dir, masks_dir):
    """
    评估整个数据集的性能
    :param images_dir: 图像目录
    :param masks_dir: 标注数据目录
    """
    image_files = [f for f in os.listdir(images_dir) if f.endswith('.png')]
    total_images = len(image_files)
    false_alarm_rates = []
    recalls = []
    precisions = []

    start_time = time.time()

    with ProcessPoolExecutor() as executor:
        futures = []
        for idx, image_file in enumerate(image_files):
            image_path = os.path.join(images_dir, image_file)
            mask_path = os.path.join(masks_dir, image_file)

            if not os.path.exists(image_path) or not os.path.exists(mask_path):
                print(f"文件不存在: {image_path} 或 {mask_path}")
                continue

            futures.append(executor.submit(process_single_image, image_path, mask_path, display_results=False))

        for idx, future in enumerate(futures):
            try:
                FAR, Recall, Precision = future.result()
                false_alarm_rates.append(FAR)
                recalls.append(Recall)
                precisions.append(Precision)

                current_time = time.time()
                elapsed_time = current_time - start_time
                remaining_time = elapsed_time / (idx + 1) * (total_images - idx - 1)

                print(
                    f"处理进度: {idx + 1}/{total_images} | 虚警率: {FAR:.4f} | 召回率: {Recall:.4f} | 精确度: {Precision:.4f} | 已用时间: {elapsed_time:.2f}s | 剩余时间: {remaining_time:.2f}s")
            except Exception as e:
                print(f"处理图像时出错: {str(e)}")
                continue

    avg_false_alarm_rate = np.mean(false_alarm_rates)
    avg_recall = np.mean(recalls)
    avg_precision = np.mean(precisions)

    print(f"\n平均虚警率: {avg_false_alarm_rate:.4f}")
    print(f"平均召回率: {avg_recall:.4f}")
    print(f"平均精确度: {avg_precision:.4f}")


if __name__ == "__main__":
    images_dir = 'D://graduateproject//picture'
    masks_dir = 'D://graduateproject//masks'
    evaluate_dataset(images_dir, masks_dir)
