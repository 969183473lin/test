import numpy as np
import cv2
import matplotlib.pyplot as plt
import time  # 导入时间模块

def calculate_local_std(image, win_size):
    """
    计算图像的局部标准差
    :param image: 输入图像
    :param win_size: 窗口大小
    :return: 局部标准差图
    """
    pad = win_size // 2
    padded_image = cv2.copyMakeBorder(image, pad, pad, pad, pad, cv2.BORDER_REFLECT)
    local_mean = cv2.blur(padded_image, (win_size, win_size))
    local_mean_sq = cv2.blur(padded_image ** 2, (win_size, win_size))
    local_std = np.sqrt(local_mean_sq - local_mean ** 2)
    return local_std[pad:-pad, pad:-pad]

def adaptive_lig_detection(image, min_win_size=3, max_win_size=7, imap_weight=0.28, gmap_weight=0.2, threshold=0.29):
    """
    自适应窗口大小的局部强度和梯度特征检测
    :param image: 输入图像路径
    :param min_win_size: 最小窗口大小（默认3）
    :param max_win_size: 最大窗口大小（默认7）
    :param imap_weight: 局部强度特征权重（默认0.6）
    :param gmap_weight: 梯度特征权重（默认0.4）
    :param threshold: 二值化阈值（默认0.35）
    :return: gmap, imap
    """
    # 记录开始时间
    start_time = time.time()

    # 读取图像并转换为浮点型
    src = cv2.imread(image, cv2.IMREAD_GRAYSCALE)
    image = src.astype(np.float32)

    # 图像尺寸
    Xsize, Ysize = src.shape

    # 初始化特征图
    gmap = np.zeros_like(image)
    imap = np.zeros_like(image)

    # ========== 自适应窗口大小选择 ==========
    # 计算局部标准差
    local_std = calculate_local_std(image, win_size=3)  # 使用3x3窗口计算局部标准差

    # 根据局部标准差动态选择窗口大小
    win_sizes = np.zeros_like(image, dtype=np.int32)
    for i in range(Xsize):
        for j in range(Ysize):
            if local_std[i, j] > 20:  # 高标准差区域，使用小窗口
                win_sizes[i, j] = min_win_size
            elif local_std[i, j] > 10:  # 中等标准差区域，使用中等窗口
                win_sizes[i, j] = 5
            else:  # 低标准差区域，使用大窗口
                win_sizes[i, j] = max_win_size

    # ========== 改进的局部强度计算 ==========
    # 使用动态窗口计算局部均值
    local_mean = np.zeros_like(image)
    for i in range(Xsize):
        for j in range(Ysize):
            win_size = win_sizes[i, j]
            pad = win_size // 2
            # 提取局部区域
            region = image[max(i - pad, 0):min(i + pad + 1, Xsize),
                     max(j - pad, 0):min(j + pad + 1, Ysize)]
            local_mean[i, j] = np.mean(region)
    imap = image - local_mean

    # ========== 梯度特征计算（优化为Sobel算子） ==========
    grad_x = cv2.Sobel(image, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(image, cv2.CV_32F, 0, 1, ksize=3)
    gmap = np.maximum(np.abs(grad_x), np.abs(grad_y))

    # ========== 特征后处理 ==========
    # 归一化处理
    imap = (imap - imap.min()) / (imap.max() - imap.min() + 1e-6)
    gmap = (gmap - gmap.min()) / (gmap.max() - gmap.min() + 1e-6)

    # 特征融合与阈值分割
    combined_map = imap_weight * imap + gmap_weight * gmap
    binary_map = combined_map > threshold

    # 记录结束时间
    end_time = time.time()

    # 计算运行时间
    run_time = end_time - start_time
    print(f"目标检测运行时间: {run_time:.4f} 秒")

    # ========== 可视化结果 ==========
    plt.figure(figsize=(15, 10))
    # 原始图像
    plt.subplot(2, 3, 1), plt.imshow(src, cmap='gray'), plt.title('Original Image')
    # 局部标准差图
    plt.subplot(2, 3, 2), plt.imshow(local_std, cmap='gray'), plt.title('Local Std Dev Map')
    # 自适应窗口大小图
    plt.subplot(2, 3, 3), plt.imshow(win_sizes, cmap='jet'), plt.title('Adaptive Window Sizes')
    # 改进的局部强度图
    plt.subplot(2, 3, 4), plt.imshow(imap, cmap='gray'), plt.title('Improved Local Intensity Map')
    # 梯度特征图
    plt.subplot(2, 3, 5), plt.imshow(gmap, cmap='gray'), plt.title('Gradient Feature Map')
    # 二值化结果
    plt.subplot(2, 3, 6), plt.imshow(binary_map, cmap='gray'), plt.title('Binary Result')
    plt.tight_layout()
    plt.show()

    return gmap, imap

# 使用示例
image_path = 'D://graduateproject//picture//000400.png'
gmap, imap = adaptive_lig_detection(image_path)