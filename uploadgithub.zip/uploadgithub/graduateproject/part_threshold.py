import numpy as np
import cv2
import matplotlib.pyplot as plt

def compute_combined_map(image_path):
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    image = image.astype(np.float32)

    # 获取图像尺寸
    Xsize, Ysize = image.shape

    # 初始化特征图
    gradient_img1 = np.zeros((Xsize, Ysize))
    gradient_img2 = np.zeros((Xsize, Ysize))
    gradient_img3 = np.zeros((Xsize, Ysize))
    gradient_img4 = np.zeros((Xsize, Ysize))
    gmap = np.zeros((Xsize, Ysize))
    imap = np.zeros((Xsize, Ysize))

    # 计算局部强度特征
    for i in range(1, Xsize - 1):
        for j in range(1, Ysize - 1):
            local_mean = np.mean(image[i-1:i+2, j-1:j+2])
            imap[i, j] = image[i, j] - local_mean

    # 计算梯度特征
    for i in range(1, Xsize - 1):
        for j in range(1, Ysize - 1):
            # 计算四个方向的梯度
            gradient_img1[i, j] = abs(image[i, j] - image[i-1, j])
            gradient_img2[i, j] = abs(image[i, j] - image[i, j-1])
            gradient_img3[i, j] = abs(image[i, j] - image[i+1, j])
            gradient_img4[i, j] = abs(image[i, j] - image[i, j+1])
            # 综合梯度特征
            gmap[i, j] = max(gradient_img1[i, j], gradient_img2[i, j],
                             gradient_img3[i, j], gradient_img4[i, j])

    # 归一化特征图
    imap = (imap - np.min(imap)) / (np.max(imap) - np.min(imap))
    gmap = (gmap - np.min(gmap)) / (np.max(gmap) - np.min(gmap))

    # 综合特征图
    combined_map = imap + gmap

    return combined_map

def explore_thresholds(combined_map, thresholds):
    target_areas = []

    for threshold in thresholds:
        binary_map = combined_map > threshold
        target_area = np.sum(binary_map)
        target_areas.append(target_area)

    return target_areas

def plot_thresholds(thresholds, target_areas):
    plt.plot(thresholds, target_areas, marker='o', linestyle='-', color='b')
    plt.xlabel('Threshold')
    plt.ylabel('Target Area')
    plt.title('Exploring Best Threshold')
    plt.grid(True)
    plt.show()

# 调用函数
image_path = 'D://graduateproject//picture//9.png'
combined_map = compute_combined_map(image_path)
thresholds = np.linspace(0, 1, 100)  # 生成100个阈值，从0到1
target_areas = explore_thresholds(combined_map, thresholds)
plot_thresholds(thresholds, target_areas)