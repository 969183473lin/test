import os
import time
import numpy as np
import cv2
from sklearn.mixture import GaussianMixture

def calculate_local_std(image, win_size):
    pad = win_size // 2
    padded_image = cv2.copyMakeBorder(image, pad, pad, pad, pad, cv2.BORDER_REFLECT)
    local_mean = cv2.blur(padded_image, (win_size, win_size))
    local_mean_sq = cv2.blur(padded_image ** 2, (win_size, win_size))
    local_std = np.sqrt(local_mean_sq - local_mean ** 2)
    return local_std[pad:-pad, pad:-pad]

def adaptive_lig_detection(image):
    Xsize, Ysize = image.shape
    image = image.astype(np.float32)

    local_std = calculate_local_std(image, win_size=3)
    win_sizes = np.zeros_like(local_std, dtype=np.int32)
    for i in range(Xsize):
        for j in range(Ysize):
            if local_std[i, j] > 20:
                win_sizes[i, j] = 3
            elif local_std[i, j] > 10:
                win_sizes[i, j] = 5
            else:
                win_sizes[i, j] = 7

    local_mean = np.zeros_like(image)
    for i in range(Xsize):
        for j in range(Ysize):
            win_size = win_sizes[i, j]
            pad = win_size // 2
            region = image[max(i - pad, 0):min(i + pad + 1, Xsize), max(j - pad, 0):min(j + pad + 1, Ysize)]
            local_mean[i, j] = np.mean(region)
    imap = image - local_mean

    edges = cv2.Canny(image.astype(np.uint8), 50, 150)
    grad_x = cv2.Sobel(image, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(image, cv2.CV_32F, 0, 1, ksize=3)
    gmap = np.maximum(np.abs(grad_x), np.abs(grad_y))
    gmap[edges == 0] = 0

    imap = (imap - imap.min()) / (imap.max() - imap.min() + 1e-6)
    gmap = (gmap - gmap.min()) / (gmap.max() - gmap.min() + 1e-6)

    combined_map = 0.28 * imap + 0.2 * gmap
    combined_map = cv2.GaussianBlur(combined_map, (3, 3), 0)

    return combined_map

def enhance_local_combined_map(combined_map, background_window_size=15):
    background_mean = cv2.blur(combined_map, (background_window_size, background_window_size))
    enhanced_map = combined_map - background_mean
    enhanced_map = np.clip(enhanced_map, 0, 1)
    return enhanced_map

def calculate_global_rarity_multiscale(enhanced_map, scales=[3, 5, 7]):
    multiscale_features = []

    for scale in scales:
        blurred = cv2.GaussianBlur(enhanced_map, (scale, scale), 0)
        multiscale_features.append(blurred)

    multiscale_features = np.array(multiscale_features)
    feature_variances = np.var(multiscale_features, axis=0)

    Z = feature_variances.reshape((-1, 1))
    gmm = GaussianMixture(n_components=3, random_state=42)
    gmm.fit(Z)
    probabilities = np.exp(gmm.score_samples(Z))
    probabilities = probabilities / probabilities.max()
    rarity_scores = 1 - probabilities
    rarity_map = rarity_scores.reshape(feature_variances.shape)

    return rarity_map

def fuse_and_normalize(local_map, global_map, alpha=0.1):
    fused_map = alpha * local_map + (1 - alpha) * global_map
    fused_map = (fused_map - fused_map.min()) / (fused_map.max() - fused_map.min() + 1e-6)
    return fused_map

def combined_detection_multiscale(image):
    local_combined = adaptive_lig_detection(image)
    enhanced_map = enhance_local_combined_map(local_combined)
    global_rarity_map = calculate_global_rarity_multiscale(enhanced_map, [3, 5, 7])
    fused_map = fuse_and_normalize(enhanced_map, global_rarity_map, 0.1)
    return fused_map

def calculate_false_alarm_rate(detection_result, ground_truth):
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    false_alarms = np.sum(detection_result & np.logical_not(ground_truth))
    non_target_areas = np.sum(np.logical_not(ground_truth))

    if non_target_areas == 0:
        return float('inf')

    false_alarm_rate = false_alarms / non_target_areas
    return false_alarm_rate

def calculate_recall(detection_result, ground_truth):
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    true_positives = np.sum(detection_result & ground_truth)
    actual_targets = np.sum(ground_truth)

    if actual_targets == 0:
        return float('inf')

    recall = true_positives / actual_targets
    return recall

def calculate_precision(detection_result, ground_truth):
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    true_positives = np.sum(detection_result & ground_truth)
    total_positives = np.sum(detection_result)

    if total_positives == 0:
        return float('inf')

    precision = true_positives / total_positives
    return precision

def evaluate_dataset(images_dir, masks_dir, threshold=0.05):
    image_files = [f for f in os.listdir(images_dir) if f.endswith('.png')]
    total_images = len(image_files)
    false_alarm_rates = []
    recalls = []
    precisions = []

    start_time = time.time()

    for idx, image_file in enumerate(image_files):
        image_path = os.path.join(images_dir, image_file)
        mask_path = os.path.join(masks_dir, image_file)

        if not os.path.exists(image_path) or not os.path.exists(mask_path):
            print(f"文件不存在: {image_path} 或 {mask_path}")
            continue

        image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)

        if image is None or mask is None:
            print(f"无法读取图像或标注: {image_path} 或 {mask_path}")
            continue

        mask = mask > 0

        fused_map = combined_detection_multiscale(image)
        detection_result = fused_map > threshold

        false_alarm_rate = calculate_false_alarm_rate(detection_result, mask)
        recall = calculate_recall(detection_result, mask)
        precision = calculate_precision(detection_result, mask)

        false_alarm_rates.append(false_alarm_rate)
        recalls.append(recall)
        precisions.append(precision)

        current_time = time.time()
        elapsed_time = current_time - start_time
        remaining_time = elapsed_time / (idx + 1) * (total_images - idx - 1)

        print(f"处理进度: {idx + 1}/{total_images} | 虚警率: {false_alarm_rate:.4f} | 召回率: {recall:.4f} | 精确度: {precision:.4f} | 已用时间: {elapsed_time:.2f}s | 剩余时间: {remaining_time:.2f}s")

    avg_false_alarm_rate = np.mean(false_alarm_rates)
    avg_recall = np.mean(recalls)
    avg_precision = np.mean(precisions)

    print(f"平均虚警率: {avg_false_alarm_rate:.4f}")
    print(f"平均召回率: {avg_recall:.4f}")
    print(f"平均精确度: {avg_precision:.4f}")

if __name__ == "__main__":
    images_dir = 'D://graduateproject//picture'
    masks_dir = 'D://graduateproject//masks'
    evaluate_dataset(images_dir, masks_dir)