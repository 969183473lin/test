import numpy as np
import cv2
import matplotlib.pyplot as plt
import time  # 导入时间模块


def top_hat_detection(image, kernel_size=15):
    """
    Top-Hat 变换检测小目标
    :param image: 输入图像（灰度图，uint8 类型）
    :param kernel_size: 形态学操作的核大小
    :return: 二值图（目标区域为255，背景为0）
    """
    # 定义形态学核
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_size, kernel_size))
    # 开运算
    opened = cv2.morphologyEx(image, cv2.MORPH_OPEN, kernel)
    # Top-Hat 变换
    top_hat = cv2.subtract(image, opened)
    # 二值化
    _, binary_map = cv2.threshold(top_hat, 50, 255, cv2.THRESH_BINARY)
    return binary_map


def calculate_far_recall_precision(detection_result, ground_truth):
    """
    计算虚警率（FAR）、召回率（Recall）和精确率（Precision）
    :param detection_result: 检测结果（二值图）
    :param ground_truth: 标注数据（二值图）
    :return: 虚警率 (FAR), 召回率 (Recall), 精确率 (Precision)
    """
    detection_result = detection_result.astype(bool)
    ground_truth = ground_truth.astype(bool)

    # 计算真正例 (TP)
    TP = np.logical_and(detection_result, ground_truth).sum()

    # 计算假正例 (FP)
    FP = np.logical_and(detection_result, ~ground_truth).sum()

    # 计算假负例 (FN)
    FN = np.logical_and(~detection_result, ground_truth).sum()

    # 计算背景像素总数 (BG)
    BG = (~ground_truth).sum()

    # 计算虚警率 (FAR)
    if BG > 0:
        FAR = FP / BG
    else:
        FAR = 0.0

    # 计算召回率 (Recall)
    if (TP + FN) > 0:
        Recall = TP / (TP + FN)
    else:
        Recall = 0.0

    # 计算精确率 (Precision)
    if (TP + FP) > 0:
        Precision = TP / (TP + FP)
    else:
        Precision = 0.0

    return FAR, Recall, Precision


def process_single_image(image_path, ground_truth_path):
    """
    处理单张图像并计算指标
    :param image_path: 图像路径
    :param ground_truth_path: 标注数据路径
    """
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"图像文件未找到: {image_path}")

    # Top-Hat 检测
    binary_map = top_hat_detection(image)

    # 读取标注数据
    ground_truth = cv2.imread(ground_truth_path, cv2.IMREAD_GRAYSCALE)
    if ground_truth is None:
        raise FileNotFoundError(f"标注数据文件未找到: {ground_truth_path}")
    ground_truth = ground_truth > 0  # 转换为二值图

    # 确保检测结果和标注数据的大小一致
    if binary_map.shape != ground_truth.shape:
        ground_truth = cv2.resize(ground_truth.astype(np.uint8), (binary_map.shape[1], binary_map.shape[0]))

    # 计算指标
    FAR, Recall, Precision = calculate_far_recall_precision(binary_map, ground_truth)

    # 输出结果
    print(f"虚警率 (FAR): {FAR:.4f}")
    print(f"召回率 (Recall): {Recall:.4f}")
    print(f"精确率 (Precision): {Precision:.4f}")
    return FAR, Recall, Precision

def test_top_hat(image_path, ground_truth_path):
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    # 记录开始时间
    start_time = time.time()

    # 运行 Top-Hat 变换
    binary_map = top_hat_detection(image)

    # 记录结束时间
    end_time = time.time()

    # 计算运行时间
    run_time = end_time - start_time
    print(f"Top-Hat 变换运行时间: {run_time:.4f} 秒")

    # 计算指标
    process_single_image(image_path, ground_truth_path)

    # 可视化结果
    #plt.figure(figsize=(10, 5))
    #plt.subplot(1, 2, 1), plt.imshow(image, cmap='gray'), plt.title('Original Image')
    #plt.subplot(1, 2, 2), plt.imshow(binary_map, cmap='gray'), plt.title('Binary Map (Top-Hat)')
    #plt.tight_layout()
    #plt.show()


# 使用示例
image_path = 'D://graduateproject//picture//000001.png'  # 输入图像路径
ground_truth_path = 'D://graduateproject//masks//000001.png'  # 真实标注图路径

test_top_hat(image_path, ground_truth_path)